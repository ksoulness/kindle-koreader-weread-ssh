#!/bin/sh
DIR="$(cd "$(dirname "$0")" && pwd)"
LOG="$DIR/reeden.log"
LOWMEM_ARG=0
if [ "$1" = "lowmem" ]; then
  LOWMEM_ARG=1
  shift
fi
rm -f /tmp/reeden-lowmem-arg
if [ -d /etc/upstart ]; then
  INIT_TYPE=upstart
  UI_PROCS="${REEDEN_PAUSE_PROCS:-awesome}"
else
  INIT_TYPE=sysv
  UI_PROCS="${REEDEN_PAUSE_PROCS:-cvm}"
fi

TOGGLED_SERVICES="stored webreader kfxreader kfxview todo tmd rcm archive scanner otav3 otaupd"
STOPPED_FILE=/tmp/reeden-stopped-services

log() { echo "[run.sh] $*" >> "$LOG"; }

ROOT="$(dirname "$DIR")"
APP="$(basename "$DIR")"
UPDATE_DIR="$ROOT/.update"

update_after_exit() {
  mode=""
  if [ -f "$UPDATE_DIR/applied" ]; then
    if [ -f "$UPDATE_DIR/ok" ]; then
      rm -rf "$ROOT/$APP.old" "$ROOT/$APP.bad"
      rm -f "$UPDATE_DIR/applied" "$UPDATE_DIR/ok"
      echo "[update] $(date) 新版启动正常，删掉旧版" >> "$UPDATE_DIR/update.log"
    elif [ -d "$ROOT/$APP.old" ]; then
      mode=rollback
    else
      rm -f "$UPDATE_DIR/applied"
    fi
  fi
  [ -z "$mode" ] && [ -f "$UPDATE_DIR/pending" ] && mode=apply
  [ -n "$mode" ] || return 0
  cat > /tmp/reeden-update.sh <<'UPDATE'
#!/bin/sh
mode="$1"; pid="$2"; ROOT="$3"; APP="$4"
U="$ROOT/.update"; MNT="$(dirname "$ROOT")"
log() { echo "[update] $(date) $*" >> "$U/update.log"; }
while kill -0 "$pid" 2>/dev/null; do sleep 1; done
case "$mode" in
  apply)
    stage="$U/stage"
    if [ ! -x "$stage/reeden/$APP/reeden-kindle" ] || [ ! -f "$stage/reeden/$APP/run.sh" ]; then
      log "更新包不完整，放弃"
      rm -rf "$stage"; rm -f "$U/pending"
      exit 0
    fi
    relaunch=0
    grep -q relaunch "$U/pending" 2>/dev/null && relaunch=1
    rm -rf "$ROOT/$APP.old"
    if ! mv "$ROOT/$APP" "$ROOT/$APP.old"; then log "挪开旧版失败，放弃"; exit 1; fi
    if ! mv "$stage/reeden/$APP" "$ROOT/$APP"; then
      mv "$ROOT/$APP.old" "$ROOT/$APP"
      log "换上新版失败，保留旧版"
      exit 1
    fi
    [ -d "$stage/extensions" ] && cp -rf "$stage/extensions/." "$MNT/extensions/" 2>/dev/null
    for f in "$stage"/documents/*.sh; do
      [ -f "$f" ] || continue
      cmp -s "$f" "$MNT/documents/$(basename "$f")" || cp -f "$f" "$MNT/documents/"
    done
    rm -rf "$stage"; rm -f "$U/pending" "$U/ok"
    : > "$U/applied"
    log "已换到新版（relaunch=$relaunch）"
    [ "$relaunch" = 1 ] && exec sh "$ROOT/$APP/run.sh"
    ;;
  rollback)
    rm -rf "$ROOT/$APP.bad"
    if mv "$ROOT/$APP" "$ROOT/$APP.bad" && mv "$ROOT/$APP.old" "$ROOT/$APP"; then
      rm -f "$U/applied" "$U/ok"
      log "新版没能正常启动，已换回旧版（新版留在 $APP.bad）"
      exec sh "$ROOT/$APP/run.sh"
    fi
    log "换回旧版失败"
    ;;
esac
UPDATE
  setsid sh /tmp/reeden-update.sh "$mode" "$$" "$ROOT" "$APP" </dev/null >/dev/null 2>&1 &
  log "退出后$( [ "$mode" = apply ] && echo 安装更新 || echo 换回旧版 )"
}

glibc_version() {
  for libc in /lib/libc.so.6 /lib/arm-linux-gnueabihf/libc.so.6; do
    [ -x "$libc" ] && "$libc" 2>/dev/null | head -1 | sed -n 's/.*version \([0-9]*\.[0-9]*\).*/\1/p' && return
  done
}

version_ge() {
  a1=${1%%.*}; a2=${1#*.}; b1=${2%%.*}; b2=${2#*.}
  [ "$a1" -gt "$b1" ] || { [ "$a1" -eq "$b1" ] && [ "$a2" -ge "$b2" ]; }
}

proc_age() {
  pid=$(pidof "$1" | awk '{print $1}')
  [ -n "$pid" ] || return 0
  hz=$(getconf CLK_TCK 2>/dev/null || echo 100)
  awk -v hz="$hz" -v start="$(awk '{print $22}' /proc/"$pid"/stat)" '{print int($1 - start / hz)}' /proc/uptime
}

stop_framework() {
  last=$(cat /tmp/reeden-resumed-at 2>/dev/null || echo 0)
  now=$(date +%s)
  if [ $((now - last)) -lt 15 ]; then
    log "Kindle 界面刚恢复，等 $((15 - now + last)) 秒再停"
    sleep $((15 - now + last))
  fi
  for i in $(seq 1 120); do
    if [ "$(lipc-get-prop com.lab126.kaf frameworkStarted 2>/dev/null)" = "1" ]; then
      [ -x /app/bin/KPPMainAppV2 ] || [ -x /app/bin/KPPMainApp ] || break
      age=$(proc_age KPPMainApp)
      [ -n "$age" ] && [ "$age" -ge 45 ] && break
    fi
    [ "$i" = 1 ] && log "等 Kindle 界面启动完再停（KPPMainApp 已运行 ${age:-0} 秒）"
    sleep 1
  done
  log "停止 lab126_gui（省内存模式）"
  stop lab126_gui >> "$LOG" 2>&1
  for i in $(seq 1 15); do
    pidof java KPPMainApp >/dev/null 2>&1 || break
    sleep 1
  done
  sleep 2
  (
    x0=$(pidof Xorg)
    while sleep 3; do
      x=$(pidof Xorg)
      if [ -n "$x" ] && [ "$x" != "$x0" ]; then
        x0="$x"
        sleep 3
        killall -USR1 reeden-kindle 2>/dev/null && log "Xorg 重启过，让嵌入器整屏写回"
      fi
    done
  ) &
  X_WATCH_PID=$!
}

straighten_screen() {
  [ "$INIT_TYPE" = "upstart" ] || return 0
  ORIENTATION=$(lipc-get-prop -s com.lab126.winmgr orientation 2>/dev/null)
  [ -n "$ORIENTATION" ] && [ "$ORIENTATION" != "U" ] || return 0
  ORIENTATION_LOCK=$(lipc-get-prop -s com.lab126.winmgr orientationLock 2>/dev/null)
  lipc-set-prop -s com.lab126.winmgr orientationLock U 2>/dev/null || return 0
  ORIENTATION_CHANGED=1
  i=0
  while [ "$(lipc-get-prop -s com.lab126.winmgr orientation 2>/dev/null)" != "U" ] && [ $i -lt 5 ]; do
    sleep 1
    i=$((i + 1))
  done
  log "系统是横屏（$ORIENTATION），请它转回竖屏：$(lipc-get-prop -s com.lab126.winmgr orientation 2>/dev/null)"
}

pause_ui() {
  if [ "$REEDEN_KEEP_AWAKE" = "1" ]; then
    (while sleep 60; do lipc-set-prop -i com.lab126.powerd touchScreenSaverTimeout 1 2>/dev/null; done) &
    KEEP_AWAKE_PID=$!
  fi
  if [ "$REEDEN_STOP_FRAMEWORK" = "1" ]; then
    stop_framework
  else
    if [ "$INIT_TYPE" = "upstart" ]; then
      lipc-set-prop com.lab126.pillow disableEnablePillow disable 2>/dev/null && log "关闭状态栏" && PILLOW_DISABLED=1
    fi
    for p in $UI_PROCS; do killall -STOP "$p" 2>/dev/null && log "暂停 $p" && PAUSED_UI="$PAUSED_UI $p"; done
    export REEDEN_PAUSED_UI="$PAUSED_UI"
    jobs=""
    [ "$REEDEN_KEEP_SERVICES" != "1" ] && jobs="$TOGGLED_SERVICES"
    [ -f /etc/upstart/statusbar.conf ] && jobs="$jobs statusbar"
    if [ "$INIT_TYPE" = "upstart" ] && [ -n "$jobs" ]; then
      : > "$STOPPED_FILE"
      (
        for job in $jobs; do
          initctl status "$job" 2>/dev/null | grep -q "start/running" || continue
          stop "$job" >/dev/null 2>&1 && echo "$job" >> "$STOPPED_FILE"
        done
        log "停止服务 $(tr '\n' ' ' < "$STOPPED_FILE")"
      ) &
      SERVICES_PID=$!
    fi
  fi
  killall -STOP volumd 2>/dev/null && VOLUMD_STOPPED=1
  for p in fsrkeypadEnable fsrkeypadPrevEnable fsrkeypadNextEnable; do
    lipc-set-prop -i com.lab126.deviced "$p" 1 2>/dev/null
  done
}

watch_gui_start() {
  timeout="${REEDEN_GUI_START_TIMEOUT:-180}"
  waited=0
  for attempt in 1 2; do
    t=0
    while [ "$t" -lt "$timeout" ]; do
      pidof reeden-kindle >/dev/null 2>&1 && return 0
      if [ "$(lipc-get-prop com.lab126.kaf frameworkStarted 2>/dev/null)" = "1" ]; then
        age=$(proc_age KPPMainApp)
        if { [ ! -x /app/bin/KPPMainAppV2 ] && [ ! -x /app/bin/KPPMainApp ]; } || { [ -n "$age" ] && [ "$age" -ge 30 ]; }; then
          log "Kindle 界面已起来（等了 $((waited + t)) 秒），打开主页整屏重画"
          lipc-set-prop com.lab126.appmgrd start app://com.lab126.booklet.home 2>/dev/null ||
            log "打开主页失败"
          return 0
        fi
      fi
      sleep 5
      t=$((t + 5))
    done
    waited=$((waited + t))
    pidof reeden-kindle >/dev/null 2>&1 && return 0
    if [ "$attempt" = 1 ]; then
      log "Kindle 界面 ${timeout} 秒没起来（lab126_gui：$(status lab126_gui 2>&1)），重启一次"
      stop lab126_gui >> "$LOG" 2>&1
      start lab126_gui >> "$LOG" 2>&1
      [ "$timeout" -lt 180 ] && timeout=180
    fi
  done
  log "Kindle 界面还是没起来（lab126_gui：$(status lab126_gui 2>&1)），要长按电源键重启 Kindle"
}

resume_ui() {
  if [ "$REEDEN_STOP_FRAMEWORK" = "1" ]; then
    [ -n "$X_WATCH_PID" ] && kill "$X_WATCH_PID" 2>/dev/null
    lipc-set-prop com.lab126.blanket load screensaver 2>/dev/null
    if [ "$REEDEN_TEST_SKIP_GUI_START" = "1" ]; then
      log "测试：不启动 lab126_gui（REEDEN_TEST_SKIP_GUI_START）"
    else
      log "启动 lab126_gui（约一分钟后回到主页）"
      start lab126_gui >> "$LOG" 2>&1
    fi
    (watch_gui_start) </dev/null >/dev/null 2>&1 &
  else
    if [ -n "$SERVICES_PID" ]; then
      wait "$SERVICES_PID" 2>/dev/null
      for job in $(cat "$STOPPED_FILE" 2>/dev/null); do start "$job" >/dev/null 2>&1; done
      rm -f "$STOPPED_FILE"
    fi
    for p in $UI_PROCS; do killall -CONT "$p" 2>/dev/null; done
    if [ "$PILLOW_DISABLED" = "1" ]; then
      lipc-set-prop com.lab126.pillow disableEnablePillow enable 2>/dev/null
      lipc-set-prop com.lab126.appmgrd start app://com.lab126.booklet.home 2>/dev/null
    fi
  fi
  [ -n "$KEEP_AWAKE_PID" ] && kill "$KEEP_AWAKE_PID" 2>/dev/null
  if [ -f /tmp/reeden-firewall-ports ]; then
    for port in $(cat /tmp/reeden-firewall-ports); do iptables -D INPUT -p tcp --dport "$port" -j ACCEPT 2>/dev/null; done
    rm -f /tmp/reeden-firewall-ports
  fi
  [ "$ORIENTATION_CHANGED" = "1" ] && lipc-set-prop -s com.lab126.winmgr orientationLock "${ORIENTATION_LOCK:-U}" 2>/dev/null
  [ "$VOLUMD_STOPPED" = "1" ] && killall -CONT volumd 2>/dev/null
  lipc-set-prop -i com.lab126.powerd preventScreenSaver 0 2>/dev/null
  date +%s > /tmp/reeden-resumed-at
}

[ -s "$LOG" ] && mv -f "$LOG" "$LOG.1"
: > "$LOG"
log "启动 $(date)"
log "$(uname -a)"
log "$(cat /etc/prettyversion.txt 2>/dev/null)"

REQUIRED="$(sed 's/GLIBC_//' "$DIR/glibc-required" 2>/dev/null)"
SYSTEM="$(glibc_version)"
MODE="${REEDEN_GLIBC:-auto}"
HARDFP=no
[ -e /lib/ld-linux-armhf.so.3 ] && HARDFP=yes
KERNEL="$(uname -r | sed -n 's/^\([0-9]*\.[0-9]*\).*/\1/p')"
if [ "$MODE" = "auto" ]; then
  if [ "$HARDFP" = "yes" ] && [ -n "$SYSTEM" ] && [ -n "$REQUIRED" ] && version_ge "$SYSTEM" "$REQUIRED"; then
    MODE=system
  elif [ -n "$KERNEL" ] && ! version_ge "$KERNEL" 3.2 && [ -e "$DIR/lib/glibc-legacy/libc.so.6" ]; then
    MODE=legacy
  else
    MODE=bundled
  fi
fi
log "系统 glibc ${SYSTEM:-未知}（硬浮点 $HARDFP），需要 ${REQUIRED:-未知}，内核 ${KERNEL:-未知}，使用 $MODE"

MEM_KB=$(awk '/MemTotal/ {print $2}' /proc/meminfo 2>/dev/null)
LOWMEM_FILE="${REEDEN_HOME:-/mnt/us/reeden/home}/.lowmem"
LOWMEM_DEFAULT=0
[ "${MEM_KB:-0}" -lt 700000 ] && LOWMEM_DEFAULT=1
LOWMEM_SUPPORTED=0
[ "$MODE" = "system" ] && [ "$INIT_TYPE" = "upstart" ] && LOWMEM_SUPPORTED=1
mkdir -p "$(dirname "$LOWMEM_FILE")"
[ "$LOWMEM_ARG" = "1" ] && echo 1 > "$LOWMEM_FILE"
LOWMEM_SETTING="$(cat "$LOWMEM_FILE" 2>/dev/null)"
if [ -z "$REEDEN_STOP_FRAMEWORK" ]; then
  case "$LOWMEM_SETTING" in
    1 | 0) REEDEN_STOP_FRAMEWORK="$LOWMEM_SETTING" ;;
    *) REEDEN_STOP_FRAMEWORK="$LOWMEM_DEFAULT" ;;
  esac
fi
if [ "$REEDEN_STOP_FRAMEWORK" = "1" ] && [ "$LOWMEM_SUPPORTED" != "1" ]; then
  log "当前固件不支持省内存模式"
  REEDEN_STOP_FRAMEWORK=0
fi
export REEDEN_LOWMEM_FILE="$LOWMEM_FILE" REEDEN_LOWMEM_DEFAULT="$LOWMEM_DEFAULT" REEDEN_LOWMEM_SUPPORTED="$LOWMEM_SUPPORTED"
for f in /mnt/us/documents/*（省内存）.sh; do
  [ -f "$f" ] && grep -q "/reeden/$APP/run.sh" "$f" && rm -rf "$f" "$f.sdr" "${f%.sh}.sdr" && log "删掉旧入口 $(basename "$f")"
done
if [ "$REEDEN_STOP_FRAMEWORK" = "1" ]; then
  log "省内存模式（内存 ${MEM_KB:-?} KB，开关 ${LOWMEM_SETTING:-没设过，按内存默认}）"
  export REEDEN_FAKE_FRAMEWORK=1 REEDEN_FRAMEWORK_STOPPED=1
fi

FONT_DIR=/tmp/reeden-fonts
mkdir -p "$FONT_DIR"
for f in ${REEDEN_SYSTEM_FONTS:-STHeitiMedium.ttf STHeitiBold.ttf}; do
  [ -f "/usr/java/lib/fonts/$f" ] && ln -sf "/usr/java/lib/fonts/$f" "$FONT_DIR/$f"
done
export FLUTTER_FONT_DIRECTORY="$FONT_DIR/"
export HOME="${REEDEN_HOME:-/mnt/us/reeden/home}"
mkdir -p "$HOME"
export REEDEN_BUNDLE_DIR="$DIR"

straighten_screen
pause_ui
trap 'resume_ui; update_after_exit' EXIT
trap 'exit 130' INT TERM

if [ "$MODE" = "bundled" ] || [ "$MODE" = "legacy" ]; then
  GLIBC_DIR="$DIR/lib/glibc"
  if [ "$MODE" = "legacy" ]; then
    GLIBC_DIR="$DIR/lib/glibc-legacy"
    export LOCPATH="$GLIBC_DIR/locale"
  fi
  "$GLIBC_DIR/reeden-kindle" --library-path "$GLIBC_DIR:$DIR/lib" "$DIR/reeden-kindle" --bundle "$DIR" "$@" >> "$LOG" 2>&1
else
  LD_LIBRARY_PATH="$DIR/lib" "$DIR/reeden-kindle" --bundle "$DIR" "$@" >> "$LOG" 2>&1
fi
log "退出码 $?"
