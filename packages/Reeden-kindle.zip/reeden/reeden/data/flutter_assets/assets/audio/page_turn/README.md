# Page turn sound presets

All six source recordings are licensed under CC0 1.0. The bundled files were
converted to 44.1 kHz, 16-bit mono WAV and tuned for low-latency UI playback.
Their perceived levels are gain-matched while preserving the quieter/louder
character of each preset. Short fades prevent clicks when a rapid page turn
restarts a sample, and the inaudible tail of `book.wav` is removed.

| Bundled file | Original recording | Author | Source |
| --- | --- | --- | --- |
| `quick.wav` | `Umblättern (kurz).wav` | MiSchy | https://freesound.org/s/369960/ |
| `quiet.wav` | `Quiet Page Turn - 8` | SpaceJoe | https://freesound.org/s/484968/ |
| `magazine.wav` | `Magazine Page` | mosaichorse | https://freesound.org/s/437121/ |
| `soft.wav` | `Page Turn Free` | AardsReal | https://freesound.org/s/842183/ |
| `natural.wav` | `Page Turning` | XanTheRock | https://freesound.org/s/537872/ |
| `book.wav` | `Page flip.wav` | cameronpride | https://freesound.org/s/676674/ |

License: https://creativecommons.org/publicdomain/zero/1.0/
