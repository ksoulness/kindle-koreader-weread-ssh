#!/bin/sh
APP="${1:-kindle_hello}"
[ $# -gt 0 ] && shift
setsid sh "/mnt/us/reeden/$APP/run.sh" "$@" </dev/null >/dev/null 2>&1 &
