local Crypto = require("weread.lib.crypto")
local ReaderState = require("weread.lib.reader_state")
local WeRead = require("weread.lib.protocol")
local logger = require("weread.lib.logger")

local Content = {}
local b64chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
-- Forward declarations used by the resumable-download checkpoint helpers.
local xml_escape
local body_fragment

local function basename_safe(value)
    value = tostring(value or ""):gsub("[^%w%._-]", "_")
    if value == "" then
        value = "weread"
    end
    return value
end

-- Directory name a book is stored under (sanitized book id). Exposed so the
-- local-cache scanner can match on-disk directory names against shelf book ids.
function Content.book_dir_name(book_id)
    return basename_safe(book_id)
end

function Content.book_cache_dir(settings, book_id)
    return settings.cache_dir .. "/" .. Content.book_dir_name(book_id)
end

-- Resolve where a book's files actually live. The current settings.cache_dir may
-- differ from where a book was downloaded (the user changed it since), so prefer
-- concrete evidence of the real location: an explicit book.cache_dir (set when any
-- file — chapter or MP article — is written), then the directory of a stored
-- cached_file/chapter path, and only as a last resort the path recomputed under
-- the current root. This keeps deletion, stats and moves on the real files instead
-- of orphaning them. MP article-only books have no cached_file, so book.cache_dir
-- is the only thing that pins them down.
function Content.book_resolved_dir(settings, book_id, book)
    if book and type(book.cache_dir) == "string" and book.cache_dir ~= "" then
        return book.cache_dir
    end
    local function dirname(path)
        if type(path) == "string" then
            return path:match("^(.*)/[^/]+$")
        end
    end
    local dir = book and dirname(book.cached_full_book or book.cached_file)
    if not dir and book and type(book.cached_chapters) == "table" then
        for _i, chapter_path in pairs(book.cached_chapters) do
            dir = dirname(chapter_path)
            if dir then
                break
            end
        end
    end
    return dir or Content.book_cache_dir(settings, book_id)
end

function Content.catalog_cache_path(settings, book)
    local book_id = book and (book.book_id or book.bookId)
    if not book_id then
        return nil
    end
    return Content.book_resolved_dir(settings, book_id, book) .. "/catalog.json"
end

function Content.save_catalog_cache(client, settings, book, chapters)
    if type(chapters) ~= "table" then
        return false, "chapter list is not a table"
    end
    local path = Content.catalog_cache_path(settings, book)
    if not path then
        return false, "missing book id"
    end
    local dir = path:match("^(.*)/[^/]+$")
    os.execute("mkdir -p " .. string.format("%q", dir))
    local ok, encoded = pcall(function()
        return client:json_encode({
            version = 1,
            updated_at = os.time(),
            chapters = chapters,
        })
    end)
    if not ok then
        return false, encoded
    end
    local tmp_path = path .. ".tmp"
    local file, err = io.open(tmp_path, "wb")
    if not file then
        return false, err
    end
    local write_ok, write_err = file:write(encoded)
    file:close()
    if not write_ok then
        os.remove(tmp_path)
        return false, write_err
    end
    local rename_ok, rename_err = os.rename(tmp_path, path)
    if not rename_ok then
        os.remove(tmp_path)
        return false, rename_err
    end
    book.cache_dir = dir
    return true, path
end

function Content.load_catalog_cache(client, settings, book)
    local path = Content.catalog_cache_path(settings, book)
    if not path then
        return nil
    end
    local file = io.open(path, "rb")
    if not file then
        return nil
    end
    local encoded = file:read("*a")
    file:close()
    local ok, decoded = pcall(function()
        return client:json_decode(encoded)
    end)
    if not ok or type(decoded) ~= "table" then
        logger.warn("ignore invalid catalog cache:", path)
        return nil
    end
    local chapters = decoded.chapters
    if type(chapters) ~= "table" then
        return nil
    end
    book.chapters = chapters
    return chapters
end

local function filename_safe(value)
    value = tostring(value or ""):gsub("[%z%c/\\:%*%?\"<>|]", "_")
    value = value:gsub("^%s+", ""):gsub("%s+$", "")
    value = value:gsub("%s+", " ")
    if value == "" then
        value = "weread"
    end
    return value
end

local function item_id(prefix, value)
    return prefix .. basename_safe(value):gsub("%.", "_")
end

local function utc_modified()
    return os.date("!%Y-%m-%dT%H:%M:%SZ")
end

local function media_type_for(data)
    if data:sub(1, 8) == "\137PNG\r\n\026\n" then
        return ".png", "image/png"
    elseif data:sub(1, 3) == "\255\216\255" then
        return ".jpg", "image/jpeg"
    elseif data:sub(1, 6) == "GIF87a" or data:sub(1, 6) == "GIF89a" then
        return ".gif", "image/gif"
    elseif data:sub(1, 4) == "RIFF" and data:sub(9, 12) == "WEBP" then
        return ".webp", "image/webp"
    end
    return ".bin", "application/octet-stream"
end

local function media_type_for_file(path)
    local file, err = io.open(path, "rb")
    if not file then return nil, nil, err end
    local head = file:read(12) or ""
    file:close()
    return media_type_for(head)
end

local function trim_nulls(value)
    return tostring(value or ""):gsub("%z.*$", ""):gsub("%s+$", "")
end

local function tar_entries(data)
    local entries = {}
    local offset = 1
    while offset + 511 <= #data do
        local header = data:sub(offset, offset + 511)
        if header:match("^%z+$") then
            break
        end
        local name = trim_nulls(header:sub(1, 100))
        local size_text = trim_nulls(header:sub(125, 136)):gsub("%s", "")
        local size = tonumber(size_text, 8) or 0
        local typeflag = header:sub(157, 157)
        local body_start = offset + 512
        local body_end = body_start + size - 1
        if name ~= "" and (typeflag == "0" or typeflag == "" or typeflag == "\0") and size > 0 then
            table.insert(entries, {
                name = name,
                data = data:sub(body_start, body_end),
            })
        end
        offset = body_start + math.ceil(size / 512) * 512
    end
    return entries
end

local function basename(path)
    return tostring(path or ""):match("([^/]+)$") or tostring(path or "")
end

local function unique_asset_name(used, name, ext)
    local base = filename_safe(name)
    if not base:lower():match(ext:gsub("%.", "%%.") .. "$") then
        base = base .. ext
    end
    local candidate = base
    local index = 2
    while used[candidate] do
        local stem = base:gsub("%.[^%.]+$", "")
        candidate = stem .. "-" .. tostring(index) .. ext
        index = index + 1
    end
    used[candidate] = true
    return candidate
end

local function write_file(path, data)
    local file, err = io.open(path, "wb")
    if not file then
        error(err)
    end
    file:write(data)
    file:close()
end

local function make_path(path)
    local ok, util = pcall(require, "util")
    if ok and util and util.makePath then
        local made, err = util.makePath(path)
        if not made then error(err or ("could not create directory: " .. path)) end
        return
    end
    local result = os.execute("mkdir -p " .. string.format("%q", path))
    if result ~= true and result ~= 0 then
        error("could not create directory: " .. path)
    end
end

local function remove_tree(path)
    if type(path) ~= "string"
        or (not path:match("/%.weread%-download%-%d+%-%d+$")
            and not path:match("/%.weread%-download%-resume%-full$")
            and not path:match("/%.weread%-download%-resume%-full/rendered%-text$")) then
        return nil, "refusing to remove an invalid download workspace"
    end
    local ok, ffiutil = pcall(require, "ffi/util")
    if not ok or not ffiutil or not ffiutil.purgeDir then
        return nil, "directory cleanup unavailable"
    end
    local called, removed, err = pcall(ffiutil.purgeDir, path)
    if not called then return nil, removed end
    if removed == false then return nil, err end
    return true
end

-- A full-book job is the only one that can run long enough to make a restart
-- meaningful. Keep its working files under a stable, book-local directory so
-- a failed transfer (or an OOM kill) can be resumed without putting book text
-- in the plugin settings file.
function Content.open_full_download_workspace(settings, book)
    local book_id = book.book_id or book.bookId
    local book_dir = Content.book_resolved_dir(settings, book_id, book)
    make_path(book_dir)
    book.cache_dir = book_dir
    local workspace = book_dir .. "/.weread-download-resume-full"
    local incoming_dir = workspace .. "/incoming"
    local asset_dir = workspace .. "/images"
    local text_dir = workspace .. "/text"
    local checkpoint_dir = workspace .. "/checkpoints"
    local rendered_text_dir = workspace .. "/rendered-text"
    make_path(incoming_dir)
    make_path(asset_dir)
    make_path(text_dir)
    make_path(checkpoint_dir)
    make_path(rendered_text_dir)
    return {
        path = workspace,
        incoming_dir = incoming_dir,
        asset_dir = asset_dir,
        text_dir = text_dir,
        checkpoint_dir = checkpoint_dir,
        rendered_text_dir = rendered_text_dir,
        resumable = true,
    }
end

local function workspace_chapter_name(chapter, chapter_index)
    return string.format("chapter-%03d.xhtml", tonumber(chapter_index) or 0)
end

local function workspace_chapter_marker(chapter)
    return "<!-- weread-chapter-uid: "
        .. basename_safe(chapter and chapter.chapterUid or "unknown") .. " -->"
end

function Content.full_download_chapter_path(workspace, chapter, chapter_index)
    if not workspace or not workspace.text_dir then return nil end
    return workspace.text_dir .. "/" .. workspace_chapter_name(chapter, chapter_index)
end

function Content.full_download_checkpoint_path(workspace, chapter, chapter_index)
    if not workspace or not workspace.checkpoint_dir then return nil end
    return workspace.checkpoint_dir .. "/" .. workspace_chapter_name(chapter, chapter_index) .. ".meta"
end

function Content.full_download_rendered_chapter_path(workspace, chapter, chapter_index)
    if not workspace or not workspace.rendered_text_dir then return nil end
    return workspace.rendered_text_dir .. "/" .. workspace_chapter_name(chapter, chapter_index)
end

function Content.full_download_rendered_chapter_exists(workspace, chapter, chapter_index)
    local path = Content.full_download_rendered_chapter_path(workspace, chapter, chapter_index)
    local file = path and io.open(path, "rb")
    if not file then return false end
    local xhtml = file:read("*a") or ""
    local closed = file:close()
    return closed and xhtml:find(workspace_chapter_marker(chapter), 1, true) ~= nil
end

local function read_full_download_checkpoint(path)
    local file = path and io.open(path, "rb")
    if not file then return nil end
    local data = file:read("*a")
    local closed = file:close()
    if not closed then return nil end
    local uid = data:match("^uid=([^\n]*)\n")
    local length = tonumber(data:match("\nlength=(%d+)\n"))
    local digest = data:match("\nsha256=([0-9a-f]+)\n")
    if not uid or not length or not digest then return nil end
    return uid, length, digest
end

function Content.full_download_chapter_exists(workspace, chapter, chapter_index)
    local path = Content.full_download_chapter_path(workspace, chapter, chapter_index)
    local file = path and io.open(path, "rb")
    if not file then return false end
    local xhtml = file:read("*a") or ""
    local closed = file:close()
    if not closed or xhtml:find(workspace_chapter_marker(chapter), 1, true) == nil then
        return false
    end
    local uid, length, digest = read_full_download_checkpoint(
        Content.full_download_checkpoint_path(workspace, chapter, chapter_index))
    return uid == basename_safe(chapter and chapter.chapterUid or "unknown")
        and length == #xhtml
        and digest == Crypto.sha256_hex(xhtml)
end

function Content.load_full_download_chapter(workspace, chapter, chapter_index)
    local path = Content.full_download_chapter_path(workspace, chapter, chapter_index)
    if not path then return nil, "chapter checkpoint is missing" end
    local file, err = io.open(path, "rb")
    if not file then return nil, err or "chapter checkpoint is missing" end
    local xhtml = file:read("*a")
    file:close()
    return xhtml
end

local function atomic_write(path, data)
    local tmp_path = path .. ".part"
    local file, err = io.open(tmp_path, "wb")
    if not file then return nil, err end
    local ok, write_err = file:write(data)
    local closed, close_err = file:close()
    if not ok or not closed then
        pcall(os.remove, tmp_path)
        return nil, write_err or close_err
    end
    local renamed, rename_err = os.rename(tmp_path, path)
    if not renamed then
        pcall(os.remove, tmp_path)
        return nil, rename_err
    end
    return true
end

local function full_download_chapter_xhtml(chapter, chapter_index, xhtml)
    local title = chapter and chapter.title
        or ("Chapter " .. tostring(chapter and chapter.chapterUid or chapter_index))
    return [[<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE html>
]] .. workspace_chapter_marker(chapter) .. [[
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops" lang="zh-CN">
<head>
<title>]] .. xml_escape(title) .. [[</title>
<link rel="stylesheet" type="text/css" href="../style.css"/>
</head>
<body>
]] .. body_fragment(xhtml) .. [[
</body>
</html>]]
end

function Content.save_full_download_chapter(workspace, chapter, chapter_index, xhtml)
    local path = Content.full_download_chapter_path(workspace, chapter, chapter_index)
    local checkpoint_path = Content.full_download_checkpoint_path(workspace, chapter, chapter_index)
    if not path or not checkpoint_path then return nil, "missing full-book workspace" end
    local chapter_xhtml = full_download_chapter_xhtml(chapter, chapter_index, xhtml)
    local ok, err = atomic_write(path, chapter_xhtml)
    if not ok then error(err or "could not checkpoint chapter") end
    local checkpoint = table.concat({
        "uid=" .. basename_safe(chapter and chapter.chapterUid or "unknown"),
        "length=" .. tostring(#chapter_xhtml),
        "sha256=" .. Crypto.sha256_hex(chapter_xhtml),
        "",
    }, "\n")
    ok, err = atomic_write(checkpoint_path, checkpoint)
    if not ok then error(err or "could not checkpoint chapter metadata") end
    return path
end

function Content.reset_full_download_rendered_text(workspace)
    if not workspace or not workspace.rendered_text_dir then
        error("missing full-book rendered workspace")
    end
    local ok, err = remove_tree(workspace.rendered_text_dir)
    if not ok then error(err or "could not reset rendered chapter workspace") end
    make_path(workspace.rendered_text_dir)
    return true
end

function Content.save_full_download_rendered_chapter(workspace, chapter, chapter_index, xhtml)
    local path = Content.full_download_rendered_chapter_path(workspace, chapter, chapter_index)
    if not path then error("missing full-book rendered workspace") end
    local ok, err = atomic_write(path, full_download_chapter_xhtml(chapter, chapter_index, xhtml))
    if not ok then error(err or "could not save rendered chapter") end
    return path
end

function Content.save_full_download_css(workspace, css)
    if not workspace or not workspace.path then return nil end
    local ok, err = atomic_write(workspace.path .. "/style.css", css or "")
    if not ok then error(err or "could not checkpoint stylesheet") end
    return true
end

function Content.load_full_download_css(workspace)
    local file = workspace and workspace.path
        and io.open(workspace.path .. "/style.css", "rb")
    if not file then return nil end
    local css = file:read("*a")
    file:close()
    return css
end

function Content.full_download_completed_chapters(workspace, chapters)
    local completed = {}
    for chapter_index, chapter in ipairs(chapters or {}) do
        if Content.full_download_chapter_exists(workspace, chapter, chapter_index) then
            completed[chapter_index] = true
        end
    end
    return completed
end

function Content.full_download_workspace_assets(workspace)
    local assets = {}
    if not workspace or not workspace.asset_dir then return assets end
    local ok_lfs, lfs = pcall(require, "libs/libkoreader-lfs")
    if not ok_lfs then ok_lfs, lfs = pcall(require, "lfs") end
    if not ok_lfs or not lfs
        or lfs.attributes(workspace.asset_dir, "mode") ~= "directory" then
        return assets
    end
    for name in lfs.dir(workspace.asset_dir) do
        if name ~= "." and name ~= ".." then
            local path = workspace.asset_dir .. "/" .. name
            if lfs.attributes(path, "mode") == "file" then
                local _, media_type = media_type_for_file(path)
                if media_type and media_type:match("^image/") then
                    table.insert(assets, {
                        href = "images/" .. name,
                        media_type = media_type,
                        path = path,
                    })
                end
            end
        end
    end
    table.sort(assets, function(a, b) return a.href < b.href end)
    return assets
end

function Content.full_download_workspace_used_asset_names(workspace)
    local used = {}
    for _, asset in ipairs(Content.full_download_workspace_assets(workspace)) do
        local name = basename(asset.href)
        if name ~= "" then used[name] = true end
    end
    return used
end

function Content.create_download_workspace(settings, book)
    local book_id = book.book_id or book.bookId
    local book_dir = Content.book_resolved_dir(settings, book_id, book)
    make_path(book_dir)
    book.cache_dir = book_dir
    local workspace = string.format("%s/.weread-download-%d-%d",
        book_dir, os.time(), math.random(100000, 999999))
    local incoming_dir = workspace .. "/incoming"
    local asset_dir = workspace .. "/images"
    make_path(incoming_dir)
    make_path(asset_dir)
    return {
        path = workspace,
        incoming_dir = incoming_dir,
        asset_dir = asset_dir,
    }
end

function Content.cleanup_download_workspace(workspace)
    local path = type(workspace) == "table" and workspace.path or workspace
    if not path then return true end
    local ok, err = remove_tree(path)
    if not ok then
        logger.warn("download workspace cleanup failed:", tostring(err))
    end
    return ok, err
end

function Content.cleanup_stale_downloads(settings)
    local ok_lfs, lfs = pcall(require, "libs/libkoreader-lfs")
    if not ok_lfs then ok_lfs, lfs = pcall(require, "lfs") end
    if not ok_lfs or not lfs then return 0 end
    local dirs = {}
    for book_id, book in pairs(settings:get("books", {}) or {}) do
        local dir = Content.book_resolved_dir(settings, book_id, book)
        dirs[dir] = true
    end
    local removed = 0
    for dir in pairs(dirs) do
        if lfs.attributes(dir, "mode") == "directory" then
            for name in lfs.dir(dir) do
                if name:match("^%.weread%-download%-%d+%-%d+$") then
                    local cleaned = remove_tree(dir .. "/" .. name)
                    if cleaned then removed = removed + 1 end
                elseif name:match("%.epub%.part$") then
                    if os.remove(dir .. "/" .. name) then removed = removed + 1 end
                elseif name:match("%.epub%.weread%-backup$") then
                    local backup = dir .. "/" .. name
                    local final = backup:gsub("%.weread%-backup$", "")
                    local current = io.open(final, "rb")
                    if current then
                        current:close()
                        if os.remove(backup) then removed = removed + 1 end
                    elseif os.rename(backup, final) then
                        removed = removed + 1
                    end
                end
            end
        end
    end
    return removed
end

local function commit_file(part_path, path)
    local renamed, rename_err = os.rename(part_path, path)
    if renamed then return true end
    local old = io.open(path, "rb")
    if not old then return nil, rename_err end
    old:close()
    local backup = path .. ".weread-backup"
    pcall(os.remove, backup)
    local backed_up, backup_err = os.rename(path, backup)
    if not backed_up then return nil, backup_err or rename_err end
    renamed, rename_err = os.rename(part_path, path)
    if not renamed then
        os.rename(backup, path)
        return nil, rename_err
    end
    pcall(os.remove, backup)
    return true
end

local function write_epub(path, entries)
    local Archiver = require("ffi/archiver")
    local archive = Archiver.Writer:new{}
    local part_path = path .. ".part"
    pcall(os.remove, part_path)
    if not archive:open(part_path, "epub") then
        error("failed to open archive for writing: " .. tostring(archive.err))
    end
    local mtime = os.time()
    local ok, err = xpcall(function()
        assert(archive:setZipCompression("store"), archive.err)
        local mimetype_data = "application/epub+zip"
        for _, entry in ipairs(entries) do
            if entry.name == "mimetype" then
                mimetype_data = entry.data
                break
            end
        end
        assert(archive:addFileFromMemory("mimetype", mimetype_data, mtime), archive.err)
        assert(archive:setZipCompression("deflate"), archive.err)
        for _, entry in ipairs(entries) do
            if entry.name ~= "mimetype" then
                local added
                if entry.path then
                    added = archive:addPath(
                        entry.name, entry.path, entry.recursive == true, mtime)
                    -- KOReader's current Writer:addPath() returns false after
                    -- a successful walk because its terminal status is EOF,
                    -- while leaving err unset. A real libarchive failure sets
                    -- err, so accept only this error-free EOF case.
                    if not added and archive.err == nil then added = true end
                else
                    added = archive:addFileFromMemory(entry.name, entry.data or "", mtime)
                end
                assert(added, archive.err or ("failed to add " .. entry.name))
            end
        end
    end, debug.traceback)
    pcall(function() archive:close() end)
    if not ok then
        pcall(os.remove, part_path)
        error(err, 0)
    end
    local committed, commit_err = commit_file(part_path, path)
    if not committed then
        pcall(os.remove, part_path)
        error(commit_err or "failed to commit EPUB", 0)
    end
end

local function append_asset_entries(entries, assets)
    local disk_dir
    for _, asset in ipairs(assets or {}) do
        if asset.path then
            local parent = asset.path:match("^(.*)/[^/]+$")
            if not parent then
                error("invalid file-backed asset path: " .. tostring(asset.path))
            end
            if disk_dir and disk_dir ~= parent then
                error("file-backed EPUB assets must share one directory")
            end
            disk_dir = parent
        else
            table.insert(entries, {
                name = "OEBPS/" .. asset.href,
                data = asset.data,
                store = asset.store,
            })
        end
    end
    if disk_dir then
        -- KOReader's libarchive wrapper is reliable for a directory tree, but
        -- some Kindle builds fail when addPath is given an individual file.
        -- All disk-backed images are staged together, so stream the directory
        -- into the EPUB with one reader lifecycle.
        table.insert(entries, {
            name = "OEBPS/images",
            path = disk_dir,
            recursive = true,
        })
    end
end

xml_escape = function(value)
    value = tostring(value or "")
    -- XML 1.0 permits tabs, newlines, and carriage returns from the C0 range,
    -- but rejects the remaining control characters. Book metadata comes from
    -- remote APIs, so remove those bytes before embedding it in the OPF.
    value = value:gsub("[%z\1-\8\11\12\14-\31]", "")
    value = value:gsub("&", "&amp;")
    value = value:gsub("<", "&lt;")
    value = value:gsub(">", "&gt;")
    value = value:gsub("\"", "&quot;")
    return value
end

-- WeRead EPUB chapters may decode to multiple concatenated XHTML documents.
-- The first <body> is often a title shell; main content lives in later bodies.
body_fragment = function(xhtml)
    xhtml = tostring(xhtml or "")
    local bodies = {}
    local remaining = xhtml
    while remaining ~= "" do
        local body_start = remaining:find("<body", 1, true)
        if not body_start then
            break
        end
        local body_open_end = remaining:find(">", body_start, true)
        if not body_open_end then
            break
        end
        local body_close = remaining:find("</body>", body_open_end, true)
        if not body_close then
            bodies[#bodies + 1] = remaining:sub(body_open_end + 1)
            break
        end
        bodies[#bodies + 1] = remaining:sub(body_open_end + 1, body_close - 1)
        remaining = remaining:sub(body_close + 7)
    end
    if #bodies > 0 then
        return table.concat(bodies, "\n")
    end
    xhtml = xhtml:gsub("<%?xml.-%?>", "")
    xhtml = xhtml:gsub("<!DOCTYPE.-%>", "")
    return xhtml
end

local function checked_body(response_text)
    if not response_text or #response_text <= 32 then
        return ""
    end
    local expected = response_text:sub(1, 32)
    local body = response_text:sub(33)
    local actual = Crypto.md5_hex(body):upper()
    if actual ~= expected then
        error("Shard MD5 mismatch")
    end
    return body
end

local function base64_decode(data)
    data = data:gsub("-", "+"):gsub("_", "/")
    local pad = #data % 4
    if pad > 0 then
        data = data .. string.rep("=", 4 - pad)
    end
    data = data:gsub("[^" .. b64chars .. "=]", "")
    return (data:gsub(".", function(char)
        if char == "=" then
            return ""
        end
        local bits = ""
        local index = b64chars:find(char, 1, true) - 1
        for bit = 6, 1, -1 do
            bits = bits .. (index % 2 ^ bit - index % 2 ^ (bit - 1) > 0 and "1" or "0")
        end
        return bits
    end):gsub("%d%d%d?%d?%d?%d?%d?%d?", function(bits)
        if #bits ~= 8 then
            return ""
        end
        local byte = 0
        for i = 1, 8 do
            if bits:sub(i, i) == "1" then
                byte = byte + 2 ^ (8 - i)
            end
        end
        return string.char(byte)
    end))
end

local function swap_positions(encoded)
    local length = #encoded
    if length < 4 then
        return {}
    end
    if length < 11 then
        return {0, 2}
    end

    local n = math.min(4, math.floor((length + 9) / 10))
    local tmp = {}
    for i = length, length - n + 1, -1 do
        local byte = encoded:byte(i)
        local bin = {}
        repeat
            table.insert(bin, 1, tostring(byte % 2))
            byte = math.floor(byte / 2)
        until byte == 0
        local value = tonumber(table.concat(bin), 4) or 0
        table.insert(tmp, tostring(value))
    end
    tmp = table.concat(tmp)

    local result = {}
    local m = length - n - 2
    local step = #tostring(m)
    local i = 1
    while #result < 10 and i + step - 1 < #tmp do
        table.insert(result, (tonumber(tmp:sub(i, i + step - 1)) or 0) % m)
        local end2 = math.min(i + step, #tmp)
        if i + 1 <= #tmp then
            table.insert(result, (tonumber(tmp:sub(i + 1, end2)) or 0) % m)
        end
        i = i + step
    end
    return result
end

local function reverse_swaps(encoded, positions)
    local chars = {}
    for i = 1, #encoded do
        chars[i] = encoded:sub(i, i)
    end
    for i = #positions, 1, -2 do
        for k = 1, 0, -1 do
            local left = positions[i] + k + 1
            local right = positions[i - 1] + k + 1
            chars[left], chars[right] = chars[right], chars[left]
        end
    end
    return table.concat(chars)
end

local function decode_encoded_body(body)
    if #body == 0 then
        return ""
    end
    local encoded = body:sub(2)
    local restored = reverse_swaps(encoded, swap_positions(encoded))
    return base64_decode(restored)
end

function Content.decode_content_shards(e0, e1, e3)
    local body = checked_body(e0) .. checked_body(e1) .. checked_body(e3)
    return decode_encoded_body(body)
end

function Content.decode_content_shard(e0)
    return decode_encoded_body(checked_body(e0))
end

function Content.extract_reader_state(html, json_decode)
    return ReaderState.extract(html, json_decode)
end

function Content.normalize_chapters(payload, book_id)
    local records = payload
    if type(payload) == "table" and payload.data then
        records = payload.data
    end
    if type(records) ~= "table" then
        return {}
    end
    if records.bookId or records.updated then
        records = { records }
    end
    for record_index, record in ipairs(records) do
        if tostring(record.bookId or "") == tostring(book_id) then
            return record.updated or record.chapterInfos or record.chapters or {}
        end
    end
    return {}
end

function Content.first_readable_chapter(chapters)
    for chapter_index, chapter in ipairs(chapters or {}) do
        if tonumber(chapter.wordCount or 0) > 0 and tostring(chapter.title or "") ~= "封面" then
            return chapter
        end
    end
end

function Content.readable_chapters(chapters)
    local out = {}
    for chapter_index, chapter in ipairs(chapters or {}) do
        if tonumber(chapter.wordCount or 0) > 0 and tostring(chapter.title or "") ~= "封面" then
            table.insert(out, chapter)
        end
    end
    return out
end

local function chapter_level(chapter)
    local level = tonumber(chapter and chapter.level or 1) or 1
    if level < 1 then
        level = 1
    elseif level > 6 then
        level = 6
    end
    return level
end

local function build_chapter_tree(chapters, filename_for)
    local root = { children = {} }
    local stack = { root }
    for chapter_index, chapter in ipairs(chapters or {}) do
        local level = chapter_level(chapter)
        if level > #stack then
            level = #stack
        end
        while #stack > level do
            table.remove(stack)
        end
        local parent = stack[#stack] or root
        local node = {
            title = chapter.title or ("Chapter " .. tostring(chapter.chapterUid or chapter_index)),
            href = filename_for(chapter_index, chapter),
            children = {},
        }
        table.insert(parent.children, node)
        stack[level + 1] = node
    end
    return root.children
end

local function build_nav_items(chapters, filename_for)
    local tree = build_chapter_tree(chapters, filename_for)
    local function render(nodes)
        local out = {}
        for node_index, node in ipairs(nodes or {}) do
            table.insert(out, [[<li><a href="]] .. xml_escape(node.href) .. [[">]] .. xml_escape(node.title) .. [[</a>]])
            if node.children and #node.children > 0 then
                table.insert(out, "<ol>")
                table.insert(out, render(node.children))
                table.insert(out, "</ol>")
            end
            table.insert(out, "</li>")
        end
        return table.concat(out, "\n")
    end

    return render(tree)
end

local function build_ncx_points(chapters, filename_for)
    local tree = build_chapter_tree(chapters, filename_for)
    local play_order = 0
    local function render(nodes)
        local out = {}
        for node_index, node in ipairs(nodes or {}) do
            play_order = play_order + 1
            local current_order = play_order
            table.insert(out, [[<navPoint id="navPoint-]] .. tostring(current_order) .. [[" playOrder="]] .. tostring(current_order) .. [[">]])
            table.insert(out, [[<navLabel><text>]] .. xml_escape(node.title) .. [[</text></navLabel>]])
            table.insert(out, [[<content src="]] .. xml_escape(node.href) .. [["/>]])
            if node.children and #node.children > 0 then
                table.insert(out, render(node.children))
            end
            table.insert(out, "</navPoint>")
        end
        return table.concat(out, "\n")
    end
    return render(tree), play_order
end

function Content.save_chapter_epub(settings, book, chapter, xhtml, assets, css)
    local book_id = book.book_id or book.bookId
    local dir = Content.book_resolved_dir(settings, book_id, book)
    os.execute("mkdir -p " .. string.format("%q", dir))
    book.cache_dir = dir
    local book_title = book.title or "WeRead"
    local path = dir .. "/" .. filename_safe(book_title .. " - " .. (chapter.title or tostring(chapter.chapterUid or "chapter"))) .. ".epub"
    local title = chapter.title or book.title or "WeRead"
    local author = book.author or "WeRead"
    local manifest_assets = {}
    for asset_index, asset in ipairs(assets or {}) do
        table.insert(manifest_assets, [[<item id="asset_]] .. tostring(asset_index) .. [[" href="]] .. xml_escape(asset.href) .. [[" media-type="]] .. xml_escape(asset.media_type) .. [["/>]])
    end
    local chapter_xhtml = [[<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops" lang="zh-CN">
<head>
<title>]] .. xml_escape(title) .. [[</title>
<link rel="stylesheet" type="text/css" href="../style.css"/>
</head>
<body>
]] .. body_fragment(xhtml) .. [[
</body>
</html>]]
    local opf = [[<?xml version="1.0" encoding="utf-8"?>
<package xmlns="http://www.idpf.org/2007/opf" unique-identifier="bookid" version="3.0" prefix="dcterms: http://purl.org/dc/terms/">
<metadata xmlns:dc="http://purl.org/dc/elements/1.1/">
<dc:identifier id="bookid">weread-]] .. xml_escape(book_id) .. [[-]] .. xml_escape(chapter.chapterUid or "chapter") .. [[</dc:identifier>
<dc:title>]] .. xml_escape(book_title) .. [[</dc:title>
<dc:creator>]] .. xml_escape(author) .. [[</dc:creator>
<dc:publisher>WeRead</dc:publisher>
<dc:source>]] .. xml_escape(WeRead.reader_url(book_id, chapter.chapterUid)) .. [[</dc:source>
<dc:language>zh-CN</dc:language>
<meta property="dcterms:modified">]] .. utc_modified() .. [[</meta>
</metadata>
<manifest>
<item id="nav" href="nav.xhtml" media-type="application/xhtml+xml" properties="nav"/>
<item id="style" href="style.css" media-type="text/css"/>
<item id="chapter" href="text/chapter.xhtml" media-type="application/xhtml+xml"/>
]] .. table.concat(manifest_assets, "\n") .. [[
</manifest>
<spine>
<itemref idref="chapter"/>
</spine>
</package>]]
    local nav = [[<?xml version="1.0" encoding="utf-8"?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head><title>Navigation</title></head>
<body>
<nav epub:type="toc" xmlns:epub="http://www.idpf.org/2007/ops">
<ol><li><a href="text/chapter.xhtml">]] .. xml_escape(title) .. [[</a></li></ol>
</nav>
</body>
</html>]]
    css = css or [[body { line-height: 1.7; margin: 5%; } img { max-width: 100%; }]]
    local entries = {
        { name = "mimetype", data = "application/epub+zip" },
        { name = "META-INF/container.xml", data = [[<?xml version="1.0" encoding="utf-8"?><container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container"><rootfiles><rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/></rootfiles></container>]] },
        { name = "OEBPS/content.opf", data = opf },
        { name = "OEBPS/nav.xhtml", data = nav },
        { name = "OEBPS/style.css", data = css },
        { name = "OEBPS/text/chapter.xhtml", data = chapter_xhtml },
    }
    append_asset_entries(entries, assets)
    write_epub(path, entries)
    Content.register_annotation_document(book, path, { chapter })
    return path
end

function Content.save_book_epub(settings, book, chapters, chapter_bodies, suffix, assets, css, cover_data)
    local book_id = book.book_id or book.bookId
    local dir = Content.book_resolved_dir(settings, book_id, book)
    os.execute("mkdir -p " .. string.format("%q", dir))
    book.cache_dir = dir
    local book_title = book.title or "WeRead"
    local path = dir .. "/" .. filename_safe(book_title .. " - " .. (suffix or "book")) .. ".epub"
    local author = book.author or "WeRead"
    local description_meta = ""
    local description = xml_escape(book.intro)
    if description ~= "" then
        description_meta = "\n<dc:description>" .. description .. "</dc:description>"
    end
    local manifest_items = {
        [[<item id="nav" href="nav.xhtml" media-type="application/xhtml+xml" properties="nav"/>]],
        [[<item id="toc" href="toc.ncx" media-type="application/x-dtbncx+xml"/>]],
        [[<item id="style" href="style.css" media-type="text/css"/>]],
    }
    local spine_items = {}
    -- Resumable full-book jobs checkpoint ready-to-package XHTML files.  The
    -- archiver can stream that directory directly, avoiding one large Lua
    -- string table for the entire book at the final packaging step.
    local workspace_text_dir = type(chapter_bodies) == "table"
        and chapter_bodies.__workspace_text_dir or nil
    local entries = {
        { name = "mimetype", data = "application/epub+zip" },
        { name = "META-INF/container.xml", data = [[<?xml version="1.0" encoding="utf-8"?><container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container"><rootfiles><rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/></rootfiles></container>]] },
    }

    local cover_meta = ""
    if cover_data and #cover_data > 0 then
        local ext, mime = media_type_for(cover_data)
        local cover_img_href = "images/cover" .. ext
        table.insert(entries, { name = "OEBPS/" .. cover_img_href, data = cover_data })
        table.insert(manifest_items, [[<item id="cover-image" href="]] .. xml_escape(cover_img_href) .. [[" media-type="]] .. xml_escape(mime) .. [[" properties="cover-image"/>]])
        table.insert(manifest_items, [[<item id="cover" href="text/cover.xhtml" media-type="application/xhtml+xml"/>]])
        table.insert(spine_items, [[<itemref idref="cover"/>]])
        local cover_xhtml = [[<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="zh-CN">
<head><title>Cover</title>
<style>html,body{margin:0;padding:0;width:100%;height:100%;overflow:hidden;}img{display:block;width:100%;height:100%;object-fit:contain;}</style>
</head>
<body><img src="../]] .. xml_escape(cover_img_href) .. [[" alt="Cover"/></body>
</html>]]
        table.insert(entries, { name = "OEBPS/text/cover.xhtml", data = cover_xhtml })
        cover_meta = '\n<meta name="cover" content="cover-image"/>'
    end

    for asset_index, asset in ipairs(assets or {}) do
        table.insert(manifest_items, [[<item id="asset_]] .. tostring(asset_index) .. [[" href="]] .. xml_escape(asset.href) .. [[" media-type="]] .. xml_escape(asset.media_type) .. [["/>]])
    end
    append_asset_entries(entries, assets)

    for chapter_index, chapter in ipairs(chapters or {}) do
        local uid = tostring(chapter.chapterUid or chapter_index)
        local filename = string.format("text/chapter-%03d.xhtml", chapter_index)
        local id = item_id("chapter_", uid)
        local title = chapter.title or ("Chapter " .. uid)
        if not workspace_text_dir then
            local chapter_xhtml = [[<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops" lang="zh-CN">
<head>
<title>]] .. xml_escape(title) .. [[</title>
<link rel="stylesheet" type="text/css" href="../style.css"/>
</head>
<body>
]] .. body_fragment(chapter_bodies[uid] or "") .. [[
</body>
</html>]]
            table.insert(entries, { name = "OEBPS/" .. filename, data = chapter_xhtml })
        end
        table.insert(manifest_items, [[<item id="]] .. id .. [[" href="]] .. filename .. [[" media-type="application/xhtml+xml"/>]])
        table.insert(spine_items, [[<itemref idref="]] .. id .. [["/>]])
    end

    local opf = [[<?xml version="1.0" encoding="utf-8"?>
<package xmlns="http://www.idpf.org/2007/opf" unique-identifier="bookid" version="3.0" prefix="dcterms: http://purl.org/dc/terms/">
<metadata xmlns:dc="http://purl.org/dc/elements/1.1/">
<dc:identifier id="bookid">weread-]] .. xml_escape(book_id) .. [[-]] .. xml_escape(suffix or "book") .. [[</dc:identifier>
<dc:title>]] .. xml_escape(book_title) .. [[</dc:title>
<dc:creator>]] .. xml_escape(author) .. [[</dc:creator>]] .. description_meta .. [[
<dc:publisher>WeRead</dc:publisher>
<dc:source>]] .. xml_escape(WeRead.reader_url(book_id)) .. [[</dc:source>
<dc:language>zh-CN</dc:language>
<meta property="dcterms:modified">]] .. utc_modified() .. [[</meta>]] .. cover_meta .. [[
</metadata>
<manifest>
]] .. table.concat(manifest_items, "\n") .. [[
</manifest>
<spine toc="toc">
]] .. table.concat(spine_items, "\n") .. [[
</spine>
</package>]]
    local ncx_points = build_ncx_points(chapters, function(chapter_index)
        return string.format("text/chapter-%03d.xhtml", chapter_index)
    end)
    local ncx = [[<?xml version="1.0" encoding="utf-8"?>
<ncx xmlns="http://www.daisy.org/z3986/2005/ncx/" version="2005-1">
<head>
<meta name="dtb:uid" content="weread-]] .. xml_escape(book_id) .. [[-]] .. xml_escape(suffix or "book") .. [["/>
<meta name="dtb:depth" content="6"/>
<meta name="dtb:totalPageCount" content="0"/>
<meta name="dtb:maxPageNumber" content="0"/>
</head>
<docTitle><text>]] .. xml_escape(book_title) .. [[</text></docTitle>
<navMap>
]] .. ncx_points .. [[
</navMap>
</ncx>]]
    local nav = [[<?xml version="1.0" encoding="utf-8"?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head><title>Navigation</title></head>
<body>
<nav epub:type="toc" xmlns:epub="http://www.idpf.org/2007/ops">
<ol>
]] .. build_nav_items(chapters, function(chapter_index)
        return string.format("text/chapter-%03d.xhtml", chapter_index)
    end) .. [[
</ol>
</nav>
</body>
</html>]]
    css = css or [[body { line-height: 1.7; margin: 5%; } img { max-width: 100%; }]]
    table.insert(entries, { name = "OEBPS/content.opf", data = opf })
    table.insert(entries, { name = "OEBPS/nav.xhtml", data = nav })
    table.insert(entries, { name = "OEBPS/toc.ncx", data = ncx })
    table.insert(entries, { name = "OEBPS/style.css", data = css })
    if workspace_text_dir then
        table.insert(entries, {
            name = "OEBPS/text",
            path = workspace_text_dir,
            recursive = true,
        })
    end
    write_epub(path, entries)
    Content.register_annotation_document(book, path, chapters)
    return path
end

function Content.rewrite_image_sources(xhtml, src_map)
    if not src_map or not next(src_map) then
        return xhtml
    end
    local function replace_src(quote, src)
        local clean = tostring(src or ""):gsub("&amp;", "&")
        local key = basename(clean:match("^[^%?#]+") or clean)
        local href = src_map[key]
        if href then
            return "src=" .. quote .. href .. quote
        end
        return "src=" .. quote .. src .. quote
    end
    xhtml = xhtml:gsub("src=(['\"])(.-)%1", replace_src)
    return xhtml
end

function Content.download_remote_images(client, xhtml, used_names, progress)
    local assets = {}
    used_names = used_names or {}
    used_names.__remote_image_hrefs = used_names.__remote_image_hrefs or {}
    local remote_image_hrefs = used_names.__remote_image_hrefs
    local function remote_url(src)
        local url = tostring(src or "")
        if url:match("^//") then
            url = "https:" .. url
        end
        if url:match("^https?://") then
            return url
        end
    end
    local img_total = 0
    xhtml:gsub('src=(["\'])(.-)%1', function(_, src)
        if remote_url(src) then
            img_total = img_total + 1
        end
    end)
    if img_total == 0 then
        return xhtml, assets
    end
    local index = 0
    local body = xhtml:gsub('src=(["\'])(.-)%1', function(quote, src)
        local url = remote_url(src)
        if not url then
            return "src=" .. quote .. src .. quote
        end
        index = index + 1
        if progress then
            progress(index, img_total)
        end
        local cached_href = remote_image_hrefs[url]
        if cached_href then
            return "src=" .. quote .. "../" .. cached_href .. quote
        end
        local ok, data = pcall(function()
            return client:get_binary(url, { referer = "https://weread.qq.com/" })
        end)
        if not ok or not data or #data == 0 then
            return "src=" .. quote .. src .. quote
        end
        local ext, mt = media_type_for(data)
        if not mt:match("^image/") then
            return "src=" .. quote .. src .. quote
        end
        local seed = basename((url:match("^[^%?#]+") or url))
        local fname = unique_asset_name(used_names, seed ~= "" and seed or ("img" .. tostring(index)), ext)
        local href = "images/" .. fname
        remote_image_hrefs[url] = href
        table.insert(assets, {
            href = href,
            media_type = mt,
            data = data,
        })
        return "src=" .. quote .. "../" .. href .. quote
    end)
    return body, assets
end

function Content.download_chapter_assets(client, book, chapter, used_names)
    if not chapter or not chapter.tar or chapter.tar == "" then
        return {}, {}
    end
    used_names = used_names or {}
    local book_id = book.book_id or book.bookId
    local referer = WeRead.reader_url(book_id, chapter.chapterUid)
    local tar_url = tostring(chapter.tar)
    if tar_url:match("^//") then
        tar_url = "https:" .. tar_url
    elseif tar_url:match("^/") then
        tar_url = "https://weread.qq.com" .. tar_url
    end
    local raw = client:get_binary(tar_url, { referer = referer })
    local assets = {}
    local src_map = {}
    for entry_index, entry in ipairs(tar_entries(raw)) do
        local ext, media_type = media_type_for(entry.data)
        if media_type:match("^image/") then
            local stem = basename(entry.name)
            local filename = unique_asset_name(used_names, stem, ext)
            local href = "images/" .. filename
            local epub_relative = "../" .. href
            table.insert(assets, {
                href = href,
                media_type = media_type,
                data = entry.data,
            })
            src_map[stem] = epub_relative
            src_map[filename] = epub_relative
        end
    end
    return assets, src_map
end

local MAX_TAR_ENTRY_BYTES = 512 * 1024 * 1024
local FILE_COPY_CHUNK_BYTES = 64 * 1024

-- WeRead's catalog field is named `tar`, but cloud-converted documents may
-- point it at a ZIP archive instead. KOReader already ships libarchive, so use
-- its format auto-detection for those resources while keeping the small TAR
-- reader below for the common streaming path.
local function extract_zip_images(archive_path, asset_dir, used_names)
    local Archiver = require("ffi/archiver")
    local archive = Archiver.Reader:new()
    local assets = {}
    local src_map = {}
    local ok, err = xpcall(function()
        if not archive:open(archive_path) then
            error(archive.err or "could not open chapter resource archive")
        end
        for entry in archive:iterate() do
            if entry.mode == "file" and entry.size > 0 then
                if entry.size > MAX_TAR_ENTRY_BYTES then
                    error("chapter resource archive entry is too large")
                end
                local data = archive:extractToMemory(entry.path)
                if not data then
                    error(archive.err or "could not extract chapter resource")
                end
                local ext, media_type = media_type_for(data)
                if media_type:match("^image/") then
                    local stem = basename(entry.path)
                    local filename = unique_asset_name(used_names, stem, ext)
                    local href = "images/" .. filename
                    local asset = { href = href, media_type = media_type }
                    if asset_dir then
                        local output = assert(io.open(asset_dir .. "/" .. filename, "wb"))
                        assert(output:write(data))
                        output:close()
                        asset.path = asset_dir .. "/" .. filename
                        asset.size = #data
                        asset.store = true
                    else
                        asset.data = data
                    end
                    table.insert(assets, asset)
                    local epub_relative = "../" .. href
                    src_map[stem] = epub_relative
                    src_map[filename] = epub_relative
                end
            end
        end
    end, debug.traceback)
    archive:close()
    if not ok then error(err, 0) end
    return assets, src_map
end

local function extract_tar_images(tar_path, asset_dir, used_names)
    local input, open_err = io.open(tar_path, "rb")
    if not input then error(open_err or "could not open chapter resource archive") end
    local assets = {}
    local src_map = {}
    local output
    local ok, err = xpcall(function()
        while true do
            local header = input:read(512)
            if not header then break end
            if #header ~= 512 then error("truncated TAR header") end
            if header:match("^%z+$") then break end
            local name = trim_nulls(header:sub(1, 100))
            local size_text = trim_nulls(header:sub(125, 136)):gsub("%s", "")
            local size = tonumber(size_text, 8)
            if not size or size < 0 or size > MAX_TAR_ENTRY_BYTES then
                error("invalid TAR entry size")
            end
            local typeflag = header:sub(157, 157)
            local is_file = name ~= "" and size > 0
                and (typeflag == "0" or typeflag == "" or typeflag == "\0")
            local first_size = math.min(size, 12)
            local first = first_size > 0 and input:read(first_size) or ""
            if #first ~= first_size then error("truncated TAR entry") end
            local remaining = size - first_size
            local ext, media_type = media_type_for(first)
            local output_path
            local filename
            if is_file and media_type:match("^image/") then
                local stem = basename(name)
                filename = unique_asset_name(used_names, stem, ext)
                output_path = asset_dir .. "/" .. filename
                output = assert(io.open(output_path, "wb"))
                assert(output:write(first))
            end
            while remaining > 0 do
                local chunk = input:read(math.min(remaining, FILE_COPY_CHUNK_BYTES))
                if not chunk or #chunk == 0 then error("truncated TAR entry") end
                remaining = remaining - #chunk
                if output then assert(output:write(chunk)) end
            end
            if output then
                output:close()
                output = nil
                local href = "images/" .. filename
                table.insert(assets, {
                    href = href,
                    media_type = media_type,
                    path = output_path,
                    size = size,
                    store = true,
                })
                local epub_relative = "../" .. href
                local stem = basename(name)
                src_map[stem] = epub_relative
                src_map[filename] = epub_relative
            end
            local padding = (512 - size % 512) % 512
            if padding > 0 then
                local skipped = input:read(padding)
                if not skipped or #skipped ~= padding then error("truncated TAR padding") end
            end
        end
    end, debug.traceback)
    if output then output:close() end
    input:close()
    if not ok then error(err, 0) end
    return assets, src_map
end

function Content.download_chapter_assets_to_files(client, book, chapter, used_names, workspace)
    if not chapter or not chapter.tar or chapter.tar == "" then return {}, {} end
    used_names = used_names or {}
    local book_id = book.book_id or book.bookId
    local referer = WeRead.reader_url(book_id, chapter.chapterUid)
    local tar_url = tostring(chapter.tar)
    if tar_url:match("^//") then
        tar_url = "https:" .. tar_url
    elseif tar_url:match("^/") then
        tar_url = "https://weread.qq.com" .. tar_url
    end
    local tar_path = string.format("%s/chapter-%s.tar",
        workspace.incoming_dir, basename_safe(chapter.chapterUid or "unknown"))
    client:download_to_file(tar_url, tar_path, {
        referer = referer,
        max_bytes = MAX_TAR_ENTRY_BYTES,
    })
    local input = assert(io.open(tar_path, "rb"))
    local signature = input:read(4) or ""
    input:close()
    local extractor = signature:sub(1, 2) == "PK"
        and extract_zip_images or extract_tar_images
    local ok, assets, src_map = pcall(
        extractor, tar_path, workspace.asset_dir, used_names)
    pcall(os.remove, tar_path)
    if not ok then error(assets, 0) end
    return assets, src_map
end

function Content.download_remote_images_to_files(client, xhtml, used_names, workspace, progress)
    local assets = {}
    used_names = used_names or {}
    used_names.__remote_image_hrefs = used_names.__remote_image_hrefs or {}
    local remote_image_hrefs = used_names.__remote_image_hrefs
    local function remote_url(src)
        local url = tostring(src or "")
        if url:match("^//") then url = "https:" .. url end
        if url:match("^https?://") then return url end
    end
    local img_total = 0
    xhtml:gsub('src=(["\'])(.-)%1', function(_, src)
        if remote_url(src) then img_total = img_total + 1 end
    end)
    local index = 0
    local body = xhtml:gsub('src=(["\'])(.-)%1', function(quote, src)
        local url = remote_url(src)
        if not url then return "src=" .. quote .. src .. quote end
        index = index + 1
        if progress then progress(index, img_total) end
        local cached_href = remote_image_hrefs[url]
        if cached_href then return "src=" .. quote .. "../" .. cached_href .. quote end
        local incoming = string.format("%s/remote-%06d.bin", workspace.incoming_dir, index)
        local ok = pcall(function()
            client:download_to_file(url, incoming, {
                referer = "https://weread.qq.com/",
                max_bytes = 64 * 1024 * 1024,
            })
        end)
        if not ok then
            pcall(os.remove, incoming)
            return "src=" .. quote .. src .. quote
        end
        local ext, mt = media_type_for_file(incoming)
        if not mt or not mt:match("^image/") then
            pcall(os.remove, incoming)
            return "src=" .. quote .. src .. quote
        end
        local seed = basename((url:match("^[^%?#]+") or url))
        local fname = unique_asset_name(used_names,
            seed ~= "" and seed or ("img" .. tostring(index)), ext)
        local output_path = workspace.asset_dir .. "/" .. fname
        local renamed = os.rename(incoming, output_path)
        if not renamed then
            pcall(os.remove, incoming)
            return "src=" .. quote .. src .. quote
        end
        local file = io.open(output_path, "rb")
        local size = file and file:seek("end") or 0
        if file then file:close() end
        local href = "images/" .. fname
        remote_image_hrefs[url] = href
        table.insert(assets, {
            href = href,
            media_type = mt,
            path = output_path,
            size = size,
            store = true,
        })
        return "src=" .. quote .. "../" .. href .. quote
    end)
    return body, assets
end

function Content.ensure_reader_state(client, book)
    local book_id = book.book_id or book.bookId
    local reader_url = book.reader_url or WeRead.reader_url(book_id)
    local reader_html = client:get_text(reader_url, { referer = reader_url })
    local state = Content.extract_reader_state(reader_html, function(encoded)
        return client:json_decode(encoded)
    end)
    book.book_id = book.book_id or state.book_id or book.bookId
    book.title = book.title or state.title
    book.author = book.author or state.author
    -- These values belong to one Web Reader session. Never retain a cached
    -- value when the freshly opened reader omits it (notably pclts).
    book.psvts = state.psvts
    book.pclts = state.pclts
    book.token = state.token
    book.reader_url = reader_url

    ReaderState.apply_to_book(book, state)

    if not book.psvts then
        error("reader.psvts not found")
    end
    return state
end

--- Refresh psvts before downloading a chapter (matches per-chapter reader page fetch).
function Content.refresh_reader_state(client, book, chapter)
    book.psvts = nil
    local book_id = book.book_id or book.bookId
    if chapter and chapter.chapterUid then
        book.reader_url = WeRead.reader_url(book_id, chapter.chapterUid)
    else
        book.reader_url = book.reader_url or WeRead.reader_url(book_id)
    end
    Content.ensure_reader_state(client, book)
end

function Content.fetch_catalog(client, book)
    local book_id = book.book_id or book.bookId
    local reader_url = book.reader_url or WeRead.reader_url(book_id)
    local catalog = client:post_json("https://weread.qq.com/web/book/chapterInfos", {
        bookIds = { tostring(book_id) },
    }, { referer = reader_url })
    local chapters = Content.readable_chapters(Content.normalize_chapters(catalog, book_id))
    book.chapters = chapters
    return chapters
end

function Content.fetch_chapter_shard(client, _settings, book, chapter, endpoint)
    if not book.psvts then
        Content.ensure_reader_state(client, book)
    end
    local book_id = book.book_id or book.bookId
    if not chapter then
        error("chapter is required")
    end

    local chapter_url = WeRead.reader_url(book_id, chapter.chapterUid)
    local is_style_shard = endpoint:find("/e_2", 1, true) ~= nil
    local params = WeRead.make_content_params(book_id, chapter.chapterUid, book.psvts, {
        sc = 1,
        style = is_style_shard,
    })
    local text, code = client:request({
        url = "https://weread.qq.com" .. endpoint,
        method = "POST",
        headers = {
            ["Content-Type"] = "application/json;charset=UTF-8",
            ["Origin"] = "https://weread.qq.com",
            ["Referer"] = chapter_url,
        },
        body = client:json_encode(params),
    })
    if not code or code < 200 or code >= 300 then
        error(endpoint .. " failed: HTTP " .. tostring(code or "unknown"))
    end
    if text == "{}" then
        error(endpoint .. " returned empty object")
    end
    return text
end

function Content.txt_to_xhtml(text)
    text = text:gsub("\r\n", "\n"):gsub("\r", "\n")
    local parts = {}
    for line in (text .. "\n"):gmatch("(.-)\n") do
        line = line:match("^(.-)%s*$") or ""
        if line ~= "" then
            table.insert(parts, "<p>" .. xml_escape(line) .. "</p>")
        end
    end
    return '<?xml version="1.0" encoding="utf-8"?>\n'
        .. '<html xmlns="http://www.w3.org/1999/xhtml"><head><title></title></head>\n'
        .. '<body>\n' .. table.concat(parts, "\n") .. '\n</body></html>'
end

function Content.fetch_txt_as_xhtml(client, settings, book, chapter)
    local t0 = Content.fetch_chapter_shard(client, settings, book, chapter, "/web/book/chapter/t_0")
    local ok_t1, t1 = pcall(Content.fetch_chapter_shard, client, settings, book, chapter, "/web/book/chapter/t_1")
    if not ok_t1 then t1 = "" end
    local plain = Content.decode_content_shards(t0, t1, "")
    Content.cache_annotation_source(settings, book, chapter, plain, true)
    return Content.txt_to_xhtml(plain)
end

function Content.fetch_chapter_xhtml(client, settings, book, chapter)
    Content.refresh_reader_state(client, book, chapter)

    if book._content_format == "txt" then
        return Content.fetch_txt_as_xhtml(client, settings, book, chapter)
    end

    local ok, e0 = pcall(Content.fetch_chapter_shard, client, settings, book, chapter, "/web/book/chapter/e_0")

    if ok and e0:sub(1, 1) == "{" and e0:find('"bookId"', 1, true) then
        book._content_format = "txt"
        return Content.fetch_txt_as_xhtml(client, settings, book, chapter)
    end

    if not ok then
        error(e0)
    end

    book._content_format = "epub"
    return Content.decode_content_shards(
        e0,
        Content.fetch_chapter_shard(client, settings, book, chapter, "/web/book/chapter/e_1"),
        Content.fetch_chapter_shard(client, settings, book, chapter, "/web/book/chapter/e_3")
    )
end

-- True when the text following the literal "0" of a font-size declaration
-- (already captured by the caller's pattern) is only an optional unit plus
-- whitespace and an optional !important flag, i.e. the declared size really is
-- zero. Zero times any unit is still zero length, so an empty tail (bare 0) and
-- every letter-unit form (px/em/rem/vh/...) count; fractional sizes such as
-- 0.5rem never match because "." is not a letter.
local function is_zero_font_size(tail)
    local value = tail:lower():match("^%s*(.-)%s*$")
    if value:sub(-10) == "!important" then
        value = (value:match("^(.-)%s*!important$") or ""):match("^%s*(.-)%s*$")
    end
    return value == "" or value == "%" or value:match("^%a+$") ~= nil
end

-- Known limitations: property-name matching is case-sensitive (all observed
-- WeRead shards are lowercase), a CSS comment containing exactly
-- "font-size: 0" may have its interior rewritten without structural harm, and
-- only top-level rules naming exactly html/body are touched (:root,
-- descendant selectors and @media-wrapped rules are left as-is).

-- True when the selector list names nothing but the root elements, i.e. every
-- comma-separated selector is exactly html or body (case- and
-- whitespace-insensitive). Compound selectors such as "body p" or
-- "body, .wrapper" also style other content, so they never qualify.
local function is_root_selector_list(selectors)
    local count = 0
    for selector in (selectors or ""):gmatch("[^,]+") do
        count = count + 1
        local name = selector:lower():gsub("^%s+", ""):gsub("%s+$", "")
        if name ~= "html" and name ~= "body" then return false end
    end
    return count > 0
end

-- Remove every zero `font-size` declaration from one braceless declaration
-- block. The sentinel "{" guarantees the boundary capture below always has a
-- character to inspect, even when the declaration opens the block.
local function strip_zero_font_sizes(block)
    local removed = 0
    local cleaned = ("{" .. block):gsub("([^%w%-])(%s*)font%-size%s*:%s*0([^;}]*)(;?)", function(boundary, leading, tail, _terminator)
        if not is_zero_font_size(tail) then
            return nil -- keep fractional sizes such as 0.5rem untouched
        end
        removed = removed + 1
        return boundary .. leading
    end)
    return cleaned:sub(2), removed
end

-- Strip hostile `font-size: 0` declarations from server-provided book css, but
-- only inside rules whose selector list is exactly `html` and/or `body`.
-- WeRead shards occasionally ship `html, body { ... font-size: 0; }`; WeRead's
-- own apps ignore root-element sizing but crengine honors it, collapsing the
-- whole book to a near-zero font size on device. Elsewhere `font-size: 0` can
-- be intentional (e.g. hiding whitespace between inline-block items), so every
-- other rule passes through verbatim.
local function sanitize_book_css_pass(css)
    local removed = 0
    -- Scan whole `selector { block }` units (balanced braces); untouched units
    -- are returned verbatim so no other declaration can be disturbed.
    local sanitized = css:gsub("([^{}]*)(%b{})", function(prelude, block)
        -- Text before the last ";" belongs to an at-rule or a previous
        -- statement, not to this block's selector list.
        local selectors = prelude:match("[^;]*$") or ""
        if not is_root_selector_list(selectors) then
            return prelude .. block
        end
        local cleaned, dropped = strip_zero_font_sizes(block:sub(2, -2))
        removed = removed + dropped
        return prelude .. "{" .. cleaned .. "}"
    end)
    return sanitized, removed
end

function Content.sanitize_book_css(css)
    if type(css) ~= "string" or css == "" then
        return css, 0
    end
    -- Each pass consumes one boundary character per match, so adjacent zero
    -- declarations ("font-size:0;font-size:0") need repeated passes until the
    -- fixpoint; the cap only guards pathological input.
    local removed_total = 0
    local sanitized = css
    for _i = 1, 16 do
        local removed
        sanitized, removed = sanitize_book_css_pass(sanitized)
        removed_total = removed_total + removed
        if removed == 0 then break end
    end
    return sanitized, removed_total
end

function Content.fetch_chapter_css(client, settings, book, chapter)
    local ok, css = pcall(function()
        return Content.decode_content_shard(Content.fetch_chapter_shard(client, settings, book, chapter, "/web/book/chapter/e_2"))
    end)
    if ok then
        local sanitized, removed = Content.sanitize_book_css(css)
        if removed > 0 then
            logger.warn("removed ", removed, " hostile font-size:0 declarations from book css")
        end
        return sanitized
    end
    return nil
end


-- Downloads always contain clean text. Annotation data is synchronized later.
local function apply_chapter_annotations(_client, _settings, _book, _chapter, xhtml, css)
    return xhtml, css
end

function Content.cache_annotation_source(settings, book, chapter, xhtml, raw_text)
    if book._content_format == "txt" and not raw_text then return end
    local ok, err = pcall(function()
        local Source = require("weread.lib.annotation_source")
        require("weread.lib.annotation_store"):new(settings):put(
            book.book_id or book.bookId, "original", tostring(chapter.chapterUid or chapter.chapterId),
            raw_text and Source.plain(xhtml) or Source.index(xhtml),
            tostring(chapter.chapterUid or chapter.chapterId))
    end)
    -- A cache failure must not turn a successful text download into a failure.
    if not ok then logger.warn("annotation source cache:", tostring(err)) end
end

function Content.register_annotation_document(book, path, chapters)
    local list = {}
    for _, chapter in ipairs(chapters) do
        list[#list + 1] = { chapterUid = chapter.chapterUid or chapter.chapterId,
            title = chapter.title, chapterIdx = chapter.chapterIdx }
    end
    book.annotation_documents = book.annotation_documents or {}
    book.annotation_documents[path] = { chapters = list, clean = true }
end

function Content.fetch_chapter_epub(client, settings, book, chapter)
    local book_id = book.book_id or book.bookId
    local xhtml = Content.fetch_chapter_xhtml(client, settings, book, chapter)
    Content.cache_annotation_source(settings, book, chapter, xhtml)
    local css = Content.fetch_chapter_css(client, settings, book, chapter)
    xhtml, css = apply_chapter_annotations(client, settings, book, chapter, xhtml, css)
    local assets = {}
    local cache = settings:get("cache", {})
    if cache.download_book_images then
        local used_names = {}
        local src_map
        assets, src_map = Content.download_chapter_assets(client, book, chapter, used_names)
        xhtml = Content.rewrite_image_sources(xhtml, src_map)
        local inline_xhtml, inline_assets = Content.download_remote_images(client, xhtml, used_names)
        xhtml = inline_xhtml
        for _, a in ipairs(inline_assets) do
            table.insert(assets, a)
        end
    end
    local path = Content.save_chapter_epub(settings, book, chapter, xhtml, assets, css)
    book.cached_chapters = book.cached_chapters or {}
    book.cached_chapters[tostring(chapter.chapterUid)] = path
    book.cached_file = path
    book.chapter_uid = chapter.chapterUid
    book.chapter_idx = chapter.chapterIdx
    book.reader_url = book.reader_url or WeRead.reader_url(book_id)
    return path, chapter
end

function Content.fetch_single_chapter_content(client, settings, book, chapter, state)
    state = state or {}
    local xhtml = Content.fetch_chapter_xhtml(client, settings, book, chapter)
    Content.cache_annotation_source(settings, book, chapter, xhtml)
    if not state.css then
        state.css = Content.fetch_chapter_css(client, settings, book, chapter)
    end
    xhtml, state.css = apply_chapter_annotations(client, settings, book, chapter, xhtml, state.css)
    local chapter_assets = {}
    local cache = settings:get("cache", {})
    if cache.download_book_images then
        state.used_asset_names = state.used_asset_names or {}
        local tar_assets, src_map = Content.download_chapter_assets(client, book, chapter, state.used_asset_names)
        for _, asset in ipairs(tar_assets) do
            table.insert(chapter_assets, asset)
        end
        xhtml = Content.rewrite_image_sources(xhtml, src_map)
        local inline_xhtml, inline_assets = Content.download_remote_images(client, xhtml, state.used_asset_names)
        xhtml = inline_xhtml
        for _, a in ipairs(inline_assets) do
            table.insert(chapter_assets, a)
        end
    end
    return xhtml, chapter_assets
end

-- Split chapter downloading around annotation fetching so the UI can request
-- thought batches cooperatively instead of blocking inside Thoughts.apply().
function Content.fetch_single_chapter_source(client, settings, book, chapter, state)
    state = state or {}
    local xhtml = Content.fetch_chapter_xhtml(client, settings, book, chapter)
    Content.cache_annotation_source(settings, book, chapter, xhtml)
    if not state.css then
        state.css = Content.fetch_chapter_css(client, settings, book, chapter)
    end
    return xhtml
end

function Content.finalize_single_chapter_content(client, settings, book, chapter, xhtml, state)
    state = state or {}
    local chapter_assets = {}
    local cache = settings:get("cache", {})
    if cache.download_book_images then
        state.used_asset_names = state.used_asset_names or {}
        local tar_assets, src_map
        if state.workspace then
            tar_assets, src_map = Content.download_chapter_assets_to_files(
                client, book, chapter, state.used_asset_names, state.workspace)
        else
            tar_assets, src_map = Content.download_chapter_assets(
                client, book, chapter, state.used_asset_names)
        end
        for _, asset in ipairs(tar_assets) do
            table.insert(chapter_assets, asset)
        end
        xhtml = Content.rewrite_image_sources(xhtml, src_map)
        local inline_xhtml, inline_assets
        if state.workspace then
            inline_xhtml, inline_assets = Content.download_remote_images_to_files(
                client, xhtml, state.used_asset_names, state.workspace,
                state.image_progress)
        else
            inline_xhtml, inline_assets = Content.download_remote_images(
                client, xhtml, state.used_asset_names, state.image_progress)
        end
        xhtml = inline_xhtml
        for _, asset in ipairs(inline_assets) do
            table.insert(chapter_assets, asset)
        end
    end
    return xhtml, chapter_assets
end

function Content.fetch_chapters_epub(client, settings, book, chapters, options)
    options = options or {}
    local selected = {}
    local bodies = {}
    local assets = {}
    local used_asset_names = {}
    local cache = settings:get("cache", {})
    local css
    for chapter_index, chapter in ipairs(chapters or {}) do
        if options.progress then
            options.progress(chapter_index, #chapters, chapter, "text")
        end
        local xhtml = Content.fetch_chapter_xhtml(client, settings, book, chapter)
    Content.cache_annotation_source(settings, book, chapter, xhtml)
        if not css then
            css = Content.fetch_chapter_css(client, settings, book, chapter)
        end
        xhtml, css = apply_chapter_annotations(client, settings, book, chapter, xhtml, css)
        if cache.download_book_images then
            if options.progress then
                options.progress(chapter_index, #chapters, chapter, "images")
            end
            local chapter_assets, src_map = Content.download_chapter_assets(client, book, chapter, used_asset_names)
            for _, asset in ipairs(chapter_assets) do
                table.insert(assets, asset)
            end
            xhtml = Content.rewrite_image_sources(xhtml, src_map)
            local inline_xhtml, inline_assets = Content.download_remote_images(client, xhtml, used_asset_names)
            xhtml = inline_xhtml
            for _, a in ipairs(inline_assets) do
                table.insert(assets, a)
            end
        end
        local uid = tostring(chapter.chapterUid or chapter_index)
        table.insert(selected, chapter)
        bodies[uid] = xhtml
    end
    if #selected == 0 then
        error("No readable chapter found")
    end
    local path = Content.save_book_epub(settings, book, selected, bodies, options.suffix or "book", assets, css)
    book.cached_chapters = book.cached_chapters or {}
    for chapter_index, chapter in ipairs(selected) do
        book.cached_chapters[tostring(chapter.chapterUid or chapter_index)] = path
    end
    book.cached_file = path
    book.reader_url = book.reader_url or WeRead.reader_url(book.book_id or book.bookId)
    return path, selected
end

function Content.fetch_first_chapter(client, settings, book)
    Content.ensure_reader_state(client, book)
    local chapters = book.chapters or Content.load_catalog_cache(client, settings, book)
    if not chapters then
        chapters = Content.fetch_catalog(client, book)
        Content.save_catalog_cache(client, settings, book, chapters)
    end
    local chapter = Content.first_readable_chapter(chapters)
    if not chapter then
        error("No readable chapter found")
    end
    return Content.fetch_chapter_epub(client, settings, book, chapter)
end

function Content.parse_mp_articles(data)
    local articles = {}
    for _, group in ipairs(data.reviews or {}) do
        for _, sub in ipairs(group.subReviews or {}) do
            local review = sub.review or sub
            local mp = review.mpInfo or {}
            local review_ids = {}
            local seen_ids = {}
            for _, review_id in ipairs({ sub.reviewId, review.reviewId, mp.originalId }) do
                review_id = tostring(review_id or "")
                if review_id ~= "" and not seen_ids[review_id] then
                    seen_ids[review_id] = true
                    table.insert(review_ids, review_id)
                end
            end
            table.insert(articles, {
                reviewId = review.reviewId or sub.reviewId or "",
                reviewIds = review_ids,
                originalId = mp.originalId or "",
                bookId = review.belongBookId or "",
                sourceUrl = mp.content_url or mp.contentUrl or mp.source_url or mp.sourceUrl or mp.url
                    or review.content_url or review.contentUrl or review.source_url or review.sourceUrl or review.url or "",
                title = mp.title or "",
                pic_url = mp.pic_url or "",
                createTime = review.createTime or 0,
            })
        end
    end
    return articles
end

function Content.extract_mp_body(html)
    html = tostring(html or "")
    local body = html:match('<div[^>]*id="js_content"[^>]*>(.-)</div>%s*<script')
    if not body then
        body = html:match('class="rich_media_content[^"]*"[^>]*>(.-)</div>%s*<script')
    end
    if not body then
        body = html:match('<div[^>]*id="js_content"[^>]*>(.*)')
    end
    if not body or body == "" then
        return nil
    end
    body = body:gsub("<script.-</script>", "")
    body = body:gsub("<style.-</style>", "")
    body = body:gsub(' src=""', '')
    body = body:gsub(" src=''", "")
    body = body:gsub("data%-src=", "src=")
    return body
end

local function normalize_void_elements(html)
    html = html:gsub("<(br)%s*>", "<%1/>")
    html = html:gsub("<(hr)%s*>", "<%1/>")
    html = html:gsub("<(img)(%s[^>]-)>", function(tag, attrs)
        if not attrs:match("/$") then
            return "<" .. tag .. attrs .. "/>"
        end
        return "<" .. tag .. attrs .. ">"
    end)
    return html
end

local function strip_mp_reader_font_styles(html)
    local blocked = {
        ["font"] = true,
        ["font-family"] = true,
        ["line-height"] = true,
        ["color"] = true,
        ["-webkit-text-fill-color"] = true,
        ["opacity"] = true,
        ["page-break-before"] = true,
        ["page-break-after"] = true,
        ["page-break-inside"] = true,
        ["break-before"] = true,
        ["break-after"] = true,
        ["break-inside"] = true,
        ["text-size-adjust"] = true,
        ["-webkit-text-size-adjust"] = true,
    }

    local function relative_heading_size(value)
        local lower = tostring(value or ""):lower():gsub("%s*!important%s*$", "")
        local px = tonumber(lower:match("^%s*([%d%.]+)%s*px%s*$"))
        if px then
            return px >= 18 and string.format("%.2fem", px / 16) or nil
        end
        local pt = tonumber(lower:match("^%s*([%d%.]+)%s*pt%s*$"))
        if pt then
            return pt >= 13.5 and string.format("%.2fem", pt / 12) or nil
        end
        local rem = tonumber(lower:match("^%s*([%d%.]+)%s*rem%s*$"))
        if rem then
            return rem > 1.05 and string.format("%.2fem", rem) or nil
        end
        local em = tonumber(lower:match("^%s*([%d%.]+)%s*em%s*$"))
        if em then
            return em > 1.05 and string.format("%.2fem", em) or nil
        end
        local percent = tonumber(lower:match("^%s*([%d%.]+)%s*%%%s*$"))
        if percent then
            return percent > 105 and string.format("%.0f%%", percent) or nil
        end
        local keyword = lower:match("^%s*(.-)%s*$")
        if keyword == "large" or keyword == "larger" or keyword == "x-large" or keyword == "xx-large" then
            return keyword
        end
        return nil
    end

    return tostring(html or ""):gsub('style=(["\'])(.-)%1', function(quote, style)
        local kept = {}
        for decl in style:gmatch("[^;]+") do
            local name, value = decl:match("^%s*([^:]+)%s*:%s*(.-)%s*$")
            if name and value then
                local property = name:lower()
                if property == "font-size" then
                    local heading_size = relative_heading_size(value)
                    if heading_size then
                        table.insert(kept, "font-size: " .. heading_size)
                    end
                elseif not blocked[property] then
                    table.insert(kept, name .. ": " .. value)
                end
            end
        end
        if #kept == 0 then
            return ""
        end
        return "style=" .. quote .. table.concat(kept, "; ") .. quote
    end)
end

function Content.strip_mp_images(html)
    html = tostring(html or "")
    html = html:gsub(
        "<[pP][iI][cC][tT][uU][rR][eE][^>]*>.-</[pP][iI][cC][tT][uU][rR][eE]%s*>",
        ""
    )
    html = html:gsub("<[iI][mM][gG][^>]*>", "")
    html = html:gsub("</[iI][mM][gG]%s*>", "")
    html = html:gsub("<[sS][oO][uU][rR][cC][eE][^>]*>", "")
    return html
end

local function strip_blank_mp_blocks(html)
    html = tostring(html or "")
    html = html:gsub("<mp%-common%-profile[^>]->.-</mp%-common%-profile>", "")
    html = html:gsub("<mp%-style%-type[^>]->.-</mp%-style%-type>", "")
    html = html:gsub("<[bB][rR]%s*/?%s*>", "<br/>")
    html = html:gsub("&nbsp;", " ")
    html = html:gsub("&#160;", " ")
    html = html:gsub("&#x[aA]0;", " ")
    html = html:gsub("\194\160", " ")

    for _ = 1, 12 do
        local previous = html
        for _, tag in ipairs({ "a", "span", "p", "section", "div", "figure", "picture" }) do
            html = html:gsub("<" .. tag .. "[^>]->%s*<br/>%s*</" .. tag .. ">", "")
            html = html:gsub("<" .. tag .. "[^>]->%s*</" .. tag .. ">", "")
        end
        if html == previous then
            break
        end
    end

    for _ = 1, 4 do
        local updated = html:gsub("(%s*<br/>%s*)%s*<br/>%s*", "<br/>")
        if updated == html then
            break
        end
        html = updated
    end
    html = html:gsub("\n%s*\n%s*\n+", "\n\n")
    return html
end

function Content.mp_article_path(settings, book, article)
    local book_id = book.book_id or book.bookId
    local dir = Content.book_resolved_dir(settings, book_id, book)
    local title = filename_safe(article.title or "article")
    return dir .. "/" .. title .. ".html"
end

-- MP articles are kept as standalone HTML files, so embedding every image as a
-- base64 data URL retains both the binary and encoded copies in Lua memory and
-- makes large articles exceed the RAM available on older e-readers. Stream the
-- images into an article-specific directory and reference those files instead.
local MP_IMAGE_MAX_BYTES = 64 * 1024 * 1024

local function mp_image_url(src)
    local url = tostring(src or ""):gsub("&amp;", "&")
    if url:match("^//") then url = "https:" .. url end
    if not url:match("^https?://mmbiz%.qpic%.cn/")
        and not url:match("^https?://mmbiz%.qlogo%.cn/") then
        return nil
    end
    return url
end

local function mp_article_asset_name(book, article)
    local key = tostring(article.reviewId or "")
    if key == "" then key = tostring(article.originalId or "") end
    if key == "" then
        key = tostring(article.bookId or book.book_id or book.bookId or "")
    end
    if key == "" then key = tostring(article.title or "article") end
    return ".weread-mp-" .. basename_safe(key) .. "-assets"
end

function Content.download_mp_images_to_files(
        client, settings, book, article, body_html, progress)
    body_html = tostring(body_html or "")
    local html_path = Content.mp_article_path(settings, book, article)
    local article_dir = html_path:match("^(.*)/[^/]+$")
    if not article_dir then
        error("Could not resolve public-account article directory")
    end

    local asset_name = mp_article_asset_name(book, article)
    local asset_dir = article_dir .. "/" .. asset_name
    make_path(asset_dir)

    local unique_urls = {}
    local total = 0
    body_html:gsub([=[src=(["'])([^"']-)["']]=], function(_quote, src)
        local url = mp_image_url(src)
        if url and unique_urls[url] == nil then
            unique_urls[url] = false
            total = total + 1
        end
    end)

    local resolved = {}
    local index = 0
    local downloaded = 0
    local body = body_html:gsub([=[src=(["'])([^"']-)["']]=], function(quote, src)
        local url = mp_image_url(src)
        if not url then return "src=" .. quote .. src .. quote end

        if resolved[url] ~= nil then
            local relative = resolved[url]
            return relative and ("src=" .. quote .. relative .. quote)
                or ("src=" .. quote .. src .. quote)
        end

        index = index + 1
        if progress then progress(index, total) end

        local stem = string.format("img-%04d", index)
        local incoming = asset_dir .. "/" .. stem .. ".download"
        local ok, download_error = pcall(function()
            client:download_to_file(url, incoming, {
                accept = "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
                referer = "https://weread.qq.com/",
                max_bytes = MP_IMAGE_MAX_BYTES,
            })
        end)
        if not ok then
            resolved[url] = false
            logger.warn("MP image download failed:", "index=", tostring(index),
                "error=", tostring(download_error))
            pcall(os.remove, incoming)
            collectgarbage("step", 64)
            return "src=" .. quote .. src .. quote
        end

        local ext, media_type, detect_error = media_type_for_file(incoming)
        if not ext or ext == ".bin"
            or not tostring(media_type):match("^image/") then
            resolved[url] = false
            logger.warn("MP image response is not a supported image:",
                "index=", tostring(index),
                "error=", tostring(detect_error or media_type))
            pcall(os.remove, incoming)
            collectgarbage("step", 64)
            return "src=" .. quote .. src .. quote
        end

        local filename = stem .. ext
        local final_path = asset_dir .. "/" .. filename
        pcall(os.remove, final_path)
        local renamed, rename_error = os.rename(incoming, final_path)
        if not renamed then
            resolved[url] = false
            logger.warn("MP image commit failed:", "index=", tostring(index),
                "error=", tostring(rename_error))
            pcall(os.remove, incoming)
            collectgarbage("step", 64)
            return "src=" .. quote .. src .. quote
        end

        local relative = asset_name .. "/" .. filename
        resolved[url] = relative
        downloaded = downloaded + 1
        collectgarbage("step", 64)
        return "src=" .. quote .. relative .. quote
    end)

    logger.info("MP images stored as local files:",
        "downloaded=", tostring(downloaded), "total=", tostring(total))
    return body
end

function Content.mp_article_cached_path(settings, book, article)
    local html_path = Content.mp_article_path(settings, book, article)
    local f = io.open(html_path, "r")
    if f then
        f:close()
        return html_path
    end
    local epub_path = html_path:gsub("%.html$", ".epub")
    f = io.open(epub_path, "r")
    if f then
        f:close()
        return epub_path
    end
    return nil
end

function Content.save_mp_article_html(settings, book, article, body_html)
    local book_id = book.book_id or book.bookId
    local dir = Content.book_resolved_dir(settings, book_id, book)
    -- Pin the real directory on the record so later lookups, moves and cleanup
    -- can find these files after the download directory changes.
    book.cache_dir = dir
    os.execute("mkdir -p " .. string.format("%q", dir))
    local title = article.title or "Article"
    local path = Content.mp_article_path(settings, book, article)
    body_html = strip_mp_reader_font_styles(body_html)
    body_html = strip_blank_mp_blocks(body_html)

    local html = [[<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8"/>
<title>]] .. xml_escape(title) .. [[</title>
<style>
html, body {
  color: #000 !important;
  font-size: 1em !important;
  line-height: 1.7;
  margin: 0;
  padding: 0;
  -webkit-text-size-adjust: 100%;
  text-size-adjust: 100%;
}
body {
  margin: 0 !important;
  padding: 0 !important;
}
body * {
  color: inherit !important;
  font-family: inherit !important;
  line-height: inherit !important;
}
img {
  display: inline !important;
  max-width: 100%;
  height: auto;
  margin: 0.2em 0 !important;
  vertical-align: middle;
  page-break-before: auto !important;
  page-break-after: auto !important;
  break-before: auto !important;
  break-after: auto !important;
}
h1 {
  font-size: 1.35em !important;
  line-height: 1.35 !important;
  margin: 0 0 1em;
}
p {
  margin: 0.25em 0 !important;
}
</style>
</head>
<body>
<h1>]] .. xml_escape(title) .. [[</h1>
]] .. body_html .. [[
</body>
</html>]]

    write_file(path, html)
    return path
end

function Content.fetch_mp_article_html(client, settings, book, article, opts)
    opts = opts or {}
    local book_id = article.bookId
    if not book_id or book_id == "" then
        book_id = book.book_id or book.bookId
    end
    local referer = book_id and book_id ~= "" and WeRead.mp_reader_url(book_id) or "https://weread.qq.com/"
    local candidate_ids = {}
    local seen_ids = {}
    local function add_candidate(review_id)
        review_id = tostring(review_id or "")
        if review_id ~= "" and not seen_ids[review_id] then
            seen_ids[review_id] = true
            table.insert(candidate_ids, review_id)
        end
    end
    add_candidate(article.reviewId)
    for _, review_id in ipairs(article.reviewIds or {}) do
        add_candidate(review_id)
    end
    add_candidate(article.originalId)
    add_candidate(tostring(article.reviewId or ""):match("^MP_WXS_%d+_(.+)$"))

    local html, meta, used_review_id
    local attempts = {}
    local function fetch_candidates(prefix, request_opts)
        for candidate_index, review_id in ipairs(candidate_ids) do
            local ok, candidate_html, candidate_meta = pcall(function()
                return client:get_mp_content(review_id, {
                    referer = referer,
                    skip_mp_auth_headers = request_opts and request_opts.skip_mp_auth_headers,
                })
            end)
            if ok then
                table.insert(
                    attempts,
                    prefix .. tostring(candidate_index) .. ":" .. tostring(candidate_meta and candidate_meta.length or #(candidate_html or ""))
                )
                if candidate_html and not candidate_html:match("^%s*$") then
                    html = candidate_html
                    meta = candidate_meta
                    used_review_id = review_id
                    return true
                end
                meta = meta or candidate_meta
            else
                table.insert(attempts, prefix .. tostring(candidate_index) .. ":error")
            end
        end
        return false
    end

    fetch_candidates("")
    if not html or html:match("^%s*$") then
        logger.info("MP content empty, renewing cookie before retry")
        local renew_ok = pcall(function()
            return client:renew_cookie()
        end)
        table.insert(attempts, renew_ok and "renew:ok" or "renew:error")
        if renew_ok then
            fetch_candidates("renewed:", { skip_mp_auth_headers = true })
        end
    end

    local source_url = tostring(article.sourceUrl or "")
    if (not html or html:match("^%s*$")) and source_url:match("^https?://mp%.weixin%.qq%.com/") then
        local ok, source_html, source_meta = pcall(function()
            return client:get_public_text(source_url)
        end)
        if ok and source_html and not source_html:match("^%s*$") then
            html = source_html
            meta = source_meta
            used_review_id = "source_url"
        else
            table.insert(attempts, "source_url:error")
        end
    end
    local body = Content.extract_mp_body(html)
    if not body then
        local empty_response = not html or html:match("^%s*$") ~= nil
        logger.warn(
            "could not extract MP article body:",
            "reason=", empty_response and "empty_response" or "missing_body",
            "candidate_count=", tostring(#candidate_ids),
            "used_candidate=", used_review_id and "yes" or "no",
            "html_length=", tostring(meta and meta.length or #(html or "")),
            "content_type=", tostring(meta and meta.content_type or ""),
            "attempts=", table.concat(attempts, ","),
            "has_source_url=", source_url ~= "" and "yes" or "no"
        )
        if empty_response then
            error("Article content response is empty. See KOReader log for details.", 0)
        end
        error("Could not extract article body. See KOReader log for details.", 0)
    end
    local cache = settings:get("cache", {})
    if cache.download_mp_images then
        body = Content.download_mp_images_to_files(
            client, settings, book, article, body, opts.progress)
    else
        body = Content.strip_mp_images(body)
    end
    return Content.save_mp_article_html(settings, book, article, body)
end

return Content
