return [[
sup.legado-review-ref,
sup.legado-review-marker {
    font-size: 0.5em;
    vertical-align: super;
    color: inherit;
    text-decoration: none;
    white-space: nowrap;
}
sup.legado-review-ref > a,
sup.legado-review-marker > a {
    color: inherit;
    text-decoration: none;
}
]]
