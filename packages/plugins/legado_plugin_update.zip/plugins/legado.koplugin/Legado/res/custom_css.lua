return [[
/* Legado 自定义
 * 启用：样式微调 → 用户样式微调 → Legado 自定义。
 * 点击用于本书；长按可设为用于所有书籍。
 * 关闭首字下沉：删除span.duokan-dropcaps-two前后的两行注释标记，保留规则。
 * 恢复首字下沉：重新注释该规则。
 * 段评标识可用 legado-review-marker-bracket/count 自定义，例如隐藏括号并添加“评”前缀。
 */
/*
span.duokan-dropcaps-two {
    float: none;
    font-size: inherit;
    line-height: inherit;
    margin: 0;
}
*/
/*
sup.legado-review-marker .legado-review-marker-bracket {
    display: none;
}
sup.legado-review-marker .legado-review-marker-count::before {
    content: "评";
}
*/
]]
